
export class DIAConstants {
  public static states: any = [
    { label: 'ANDAMAN  AND NICOBAR ISLANDS', value: 'ANDAMAN  AND NICOBAR ISLANDS' },
    { label: 'ANDHRA PRADESH', value: 'ANDHRA PRADESH' },
    { label: 'ARUNACHAL PRADESH', value: 'ARUNACHAL PRADESH' },
    { label: 'ASSAM', value: 'ASSAM' },
    { label: 'BIHAR', value: 'BIHAR' },
    { label: 'CHANDIGARH', value: 'CHANDIGARH' },
    { label: 'CHHATTISGARH', value: 'CHHATTISGARH' },
    { label: 'DADRA  AND NAGAR HAVELI', value: 'DADRA  AND NAGAR HAVELI' },
    { label: 'DAMAN AND DIU', value: 'DAMAN AND DIU' },
    { label: 'DELHI', value: 'DELHI' },
    { label: 'GOA', value: 'GOA' },
    { label: 'GUJARAT', value: 'GUJARAT' },
    { label: 'HARYANA', value: 'HARYANA' },
    { label: 'HIMACHAL PRADESH', value: 'HIMACHAL PRADESH' },
    { label: 'JAMMU  AND KASHMIR', value: 'JAMMU  AND KASHMIR' },
    { label: 'JHARKHAND', value: 'JHARKHAND' },
    { label: 'KARNATAKA', value: 'KARNATAKA' },
    { label: 'KERALA', value: 'KERALA' },
    { label: 'LAKSHADWEEP', value: 'LAKSHADWEEP' },
    { label: 'MADHYA PRADESH', value: 'MADHYA PRADESH' },
    { label: 'MAHARASHTRA', value: 'MAHARASHTRA' },
    { label: 'MANIPUR', value: 'MANIPUR' },
    { label: 'MEGHALAYA', value: 'MEGHALAYA' },
    { label: 'MIZORAM', value: 'MIZORAM' },
    { label: 'NAGALAND', value: 'NAGALAND' },
    { label: 'NCT OF DELHI', value: 'NCT OF DELHI' },
    { label: 'ODISHA', value: 'ODISHA' },
    { label: 'PUDUCHERRY', value: 'PUDUCHERRY' },
    { label: 'PUNJAB', value: 'PUNJAB' },
    { label: 'RAJASTHAN', value: 'RAJASTHAN' },
    { label: 'SIKKIM', value: 'SIKKIM' },
    { label: 'TAMIL NADU', value: 'TAMIL NADU' },
    { label: 'TRIPURA', value: 'TRIPURA' },
    { label: 'UTTARAKHAND', value: 'UTTARAKHAND' },
    { label: 'UTTAR PRADESH', value: 'UTTAR PRADESH' },
    { label: 'WEST BENGAL', value: 'WEST BENGAL' }
  ];

  public static upToFive: any = [
    { label: '1', value: '1' },
    { label: '2', value: '2' },
    { label: '3', value: '3' },
    { label: '4', value: '4' },
    { label: '5', value: '5' }
  ];

  public static upToFour: any = [
    { label: '1', value: '1' },
    { label: '2', value: '2' },
    { label: '3', value: '3' },
    { label: '4', value: '4' }
  ];

  public static upToThree: any = [
    { label: '1', value: '1' },
    { label: '2', value: '2' },
    { label: '3', value: '3' }
  ];

  public static constitution: any = [
    { label: 'Association of Persons', value: 'Association of Persons' },
    { label: 'Body of Persons', value: 'Body of Persons' },
    { label: 'Club', value: 'Club' },
    { label: 'HUF', value: 'HUF' },
    { label: 'Individual', value: 'Individual' },
    { label: 'Limited Liability Partnership', value: 'Limited Liability Partnership' },
    { label: 'Others', value: 'Others' },
    { label: 'Partnership Firm', value: 'Partnership Firm' },
    { label: 'Private Ltd Co.', value: 'Private Ltd Co.' },
    { label: 'Propriertorship', value: 'Propriertorship' },
    { label: 'Public Ltd - Listed', value: 'Public Ltd - Listed' },
    { label: 'Public Ltd - Unlisted', value: 'Public Ltd - Unlisted' },
    { label: 'Self Help Group', value: 'Self Help Group' },
    { label: 'Society', value: 'Society' },
    { label: 'Trust', value: 'Trust' }
    // { label: 'Partnership Form', value: 'Partnership Form' }
  ];

  public static salutation: any = [
    { label: 'Shri', value: 'Shri' },
    { label: 'Mr.', value: 'Mr.' },
    { label: 'Mrs.', value: 'Mrs.' },
    { label: 'Ms.', value: 'Ms.' },
    { label: 'Dr.', value: 'Dr.' },
    { label: 'Dr. (Mrs.)', value: 'Dr. (Mrs.)' },
    { label: 'Miss.', value: 'Miss.' },
    { label: 'M/s.', value: 'M/s.' },
    { label: 'Flying Officer', value: 'Flying Officer' },
    { label: 'Addl Director General-Addl DG', value: 'Addl Director General-Addl DG' },
    { label: 'Admiral', value: 'Admiral' },
    { label: 'Admiral of the Fleet', value: 'Admiral of the Fleet' },
    { label: 'Air Chief Marshal', value: 'Air Chief Marshal' },
    { label: 'Air Commodore', value: 'Air Commodore' },
    { label: 'Air Crafts Man - AC', value: 'Air Crafts Man - AC' },
    { label: 'Air Marshal', value: 'Air Marshal' },
    { label: 'Air Vice Marshal', value: 'Air Vice Marshal' },
    { label: 'Assistant Commandant-AC', value: 'Assistant Commandant-AC' },
    { label: 'Asst Sub-Inspector-ASI', value: 'Asst Sub-Inspector-ASI' },
    { label: 'Bharatratna', value: 'Bharatratna' },
    { label: 'Brigadier', value: 'Brigadier' },
    { label: 'Buglers-Bug', value: 'Buglers-Bug' },
    { label: 'CORPORAL - Cpl.', value: 'CORPORAL - Cpl.' },
    { label: 'Captain', value: 'Captain' },
    { label: 'Chief Petty Officer - CPO', value: 'Chief Petty Officer - CPO' },
    { label: 'Colonel', value: 'Colonel' },
    { label: 'Commandant-Comdt', value: 'Commandant-Comdt' },
    { label: 'Commander', value: 'Commander' },
    { label: 'Commodore (Cmde)', value: 'Commodore (Cmde)' },
    { label: 'Constable-CT', value: 'Constable-CT' },
    { label: 'Wing Commander', value: 'Wing Commander' },
    { label: 'Deputy Commandant-DC', value: 'Deputy Commandant-DC' },
    { label: 'Deputy Inspector General -DIG', value: 'Deputy Inspector General -DIG' },
    { label: 'Director General -DG', value: 'Director General -DG' },
    { label: 'Enrolled Follower-Enrl Foll', value: 'Enrolled Follower-Enrl Foll' },
    { label: 'Flt.Lieutenant', value: 'Flt.Lieutenant' },
    { label: 'General', value: 'General' },
    { label: 'Group Captain', value: 'Group Captain' },
    { label: 'Havaldar', value: 'Havaldar' },
    { label: 'Havaldar Major-CHM', value: 'Havaldar Major-CHM' },
    { label: 'Head Constable-HC', value: 'Head Constable-HC' },
    { label: 'Honorary Captain', value: 'Honorary Captain' },
    { label: 'Honorary Lieutenant', value: 'Honorary Lieutenant' },
    { label: 'Inspector General-IG', value: 'Inspector General-IG' },
    { label: 'Inspector-Insp', value: 'Inspector-Insp' },
    { label: 'unior Warrant Officer - JWO', value: 'unior Warrant Officer - JWO' },
    { label: 'Lance Naik', value: 'Lance Naik' },
    { label: 'Leading Seaman - LS', value: 'Leading Seaman - LS' },
    { label: 'Lieutenant', value: 'Lieutenant' },
    { label: 'Lieutenant Colonel', value: 'Lieutenant Colonel' },
    { label: 'Lieutenant Commander', value: 'Lieutenant Commander' },
    { label: 'Lt.General', value: 'Lt.General' },
    { label: 'Major', value: 'Major' },
    { label: 'Major General', value: 'Major General' },
    { label: 'Master', value: 'Master' },
    { label: 'Master Chief Petty Offr MCPO I', value: 'Master Chief Petty Offr MCPO I' },
    { label: 'Master Chief Petty Offr MCPOII ', value: 'Master Chief Petty Offr MCPOII' },
    { label: 'Master Warrant Officer - MWO', value: 'Master Warrant Officer - MWO' },
    { label: 'Mule Drivers-M Dvr ', value: 'Mule Drivers-M Dvr ' },
    { label: 'Naib Subedar ', value: 'Naib Subedar ' },
    { label: 'Naik', value: 'Naik' },
    { label: 'Nalband', value: 'Nalband' },
    { label: 'Padmabhushan', value: 'Padmabhushan' },
    { label: 'Padmashri', value: 'Padmashri' },
    { label: 'Padmavibhushan', value: 'Padmavibhushan' },
    { label: 'Petty Officer - PO', value: 'Petty Officer - PO' },
    { label: 'Pilot Officer', value: 'Pilot Officer' },
    { label: 'Rear Admiral', value: 'Rear Admiral' },
    { label: 'Riflemen-Rfn', value: 'Riflemen-Rfn' },
    { label: 'Sea I', value: 'Sea I' },
    { label: 'Sea II', value: 'Sea II' },
    { label: 'Second-in-Command-2-I/C', value: 'Second-in-Command-2-I/C' },
    { label: 'Sepoy', value: 'Sepoy' },
    { label: 'Sergeant - Sgt.', value: 'Sergeant - Sgt.' },
    { label: 'Spl Director General-Spl DG', value: 'Spl Director General-Spl DG' },
    { label: 'Squadron Leader', value: 'Squadron Leader' },
    { label: 'Sub Lieutenant', value: 'Sub Lieutenant' },
    { label: 'Sub-Inspector-SI', value: 'Sub-Inspector-SI' },
    { label: 'Subedar', value: 'Subedar' },
    { label: 'Warrant Officer - WO', value: 'Warrant Officer - WO' },
    { label: 'Vice Admiral (V Adm)', value: 'Vice Admiral (V Adm)' },
  ];

  public static ownership: any = [
    { label: 'Rented', value: 'Rented' },
    { label: 'Owed', value: 'Owed' },
    { label: 'Leased', value: 'Leased' }
  ];

  public static proposedActivity: any = [
    { label: 'Same as existing', value: 'Same as existing' },
    { label: 'New', value: 'New' }
  ];

  public static reviewStatus: any = [
    { label: 'All', value: '' },
    { label: 'PRE-COMPLETED', value: 'PRE-COMPLETED' },
    { label: 'REJECTED', value: 'REJECTED' },
    { label: 'ACCEPTED', value: 'ACCEPTED' }
  ];

  public static loanReqType: any = [
    { label: 'Cash Credit', value: 'Cash Credit' },
    { label: 'BD', value: 'BD' },
    { label: 'DL', value: 'DL' },
    { label: 'WCDL', value: 'WCDL' },
    { label: 'EPC', value: 'EPC' },
    { label: 'FBD', value: 'FBD' },
    { label: 'OD', value: 'OD' },
    { label: 'Term Loan', value: 'Term Loan' },
    { label: 'Letter Of Credit', value: 'Letter Of Credit' },
    { label: 'Bank Guarantee', value: 'Bank Guarantee' },
    { label: 'SME Credit Plus', value: 'SME Credit Plus' },
    { label: 'Stand By Line Of Credit', value: 'Stand By Line Of Credit' },
    { label: 'ECB', value: 'ECB' },
    { label: 'FCL', value: 'FCL' },
    { label: 'Derivative (FC/CEL)', value: 'Derivative (FC/CEL)' },
    { label: 'Ad-hoc, if any', value: 'Ad-hoc, if any' },
    { label: 'Others', value: 'Others' }
  ];

  public static facilityType: any = [
    { label: 'Cash Credit', value: 'Cash Credit' },
    { label: 'BD', value: 'BD' },
    { label: 'DL', value: 'DL' },
    { label: 'WCDL', value: 'WCDL' },
    { label: 'EPC', value: 'EPC' },
    { label: 'FBD', value: 'FBD' },
    { label: 'OD', value: 'OD' },
    { label: 'Term Loan', value: 'Term Loan' },
    { label: 'Letter Of Credit', value: 'Letter Of Credit' },
    { label: 'Bank Guarantee', value: 'Bank Guarantee' },
    { label: 'SME Credit Plus', value: 'SME Credit Plus' },
    { label: 'Stand By Line Of Credit', value: 'Stand By Line Of Credit' },
    { label: 'ECB', value: 'ECB' },
    { label: 'FCL', value: 'FCL' },
    { label: 'Derivative (FC/CEL)', value: 'Derivative (FC/CEL)' },
    { label: 'Ad-hoc, if any', value: 'Ad-hoc, if any' },
    { label: 'Others', value: 'Others' }
  ];

  public static purposeOfLoan: any = [
    { label: 'Working capital', value: 'Working capital' },
    { label: 'Procuring Machinery', value: 'Procuring Machinery' },
    { label: 'Others', value: 'Others' }
  ];

  public static applicationSource: any = [
    { label: 'Branch', value: 'Branch' },
    { label: 'MPST', value: 'MPST' },
    { label: 'Others', value: 'Others' }
  ];

  public static reviewer: any = [
    { name: '', code: '' },
    { name: '', code: '' },
    { name: '', code: '' }
  ];


  public static relationshipFirm: any = [
    { label: 'Chief Executive', value: 'Chief Executive' },
    { label: 'Chief Promoter', value: 'Chief Promoter' },
    { label: 'Co Borrower', value: 'Co Borrower' },
    { label: 'Director', value: 'Director' },
    { label: 'Key Person', value: 'Key Person' },
    { label: 'Partner', value: 'Partner' },
    { label: 'Promoter', value: 'Promoter' },
    { label: 'Proprietor', value: 'Proprietor' }
  ];

  public static relationshipGuarantor: any = [
    { label: 'FATHER', value: 'FATHER' },
    { label: 'SPOUSE', value: 'SPOUSE' },
  ];
}
