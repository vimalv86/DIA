import { Injectable } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { Observable } from 'rxjs/Observable';
import * as shajs from 'sha.js';
declare var CryptoJS: any;
declare var sjcl: any;

@Injectable()

export class CryptoService {
    key: any;
    ivKey: any;

    createKeyForEncryption(data) {
        var formattedPFID = data.toString() + data.toString();
        formattedPFID = formattedPFID.substring(0, 10);
        var hashPFID = data.toString() + "#" + data.toString();
        var hash = sjcl.hash.sha256.hash(hashPFID);
        var outString = sjcl.codec.hex.fromBits(hash);
        var secretKey = formattedPFID + outString;
        var keyBytes = secretKey.toString().substring(0, 32);
        var key = CryptoJS.enc.Latin1.parse(keyBytes);
        return key;
    }

    createIVKey(data) {
        var reverseString = this.reverseString(data.toString());
        var reverseHashData = reverseString + "#" + reverseString;
        var hash = sjcl.hash.sha256.hash(reverseHashData);
        var outString = sjcl.codec.hex.fromBits(hash);
        var ivKey = reverseString + outString;
        var ivBytes = ivKey.toString().substring(0, 16);
        var iv = CryptoJS.enc.Latin1.parse(ivBytes);
        return iv;
    }

    generateKey(data) {
        this.key = this.createKeyForEncryption(data);
        localStorage.setItem("keyEncrypted", this.key);
    }

    generateIVKey(data) {
        this.ivKey = this.createIVKey(data);
        localStorage.setItem("ivKeyEncrypted", this.ivKey);
    }

    reverseString(data) {
        var array = data.split("");
        array.reverse();
        var str = array.join('');
        return str;
    }

    formatInputData(inputData) {
        var find = "\\\"";
        var regExp = new RegExp(find, 'g');
        inputData = inputData.replace(regExp, "\\\"");
        return inputData;
    }

    encryptData(data) {
        var encryptedData = CryptoJS.AES.encrypt(JSON.stringify(data), this.key, {
            iv: this.ivKey,
            mode: CryptoJS.mode.CBC
        }).ciphertext.toString(CryptoJS.enc.Base64);
        return encryptedData;
    }

    decryptData(data) {
        var decryptedData = CryptoJS.AES.decrypt(CryptoJS.lib.CipherParams.create({
            ciphertext: CryptoJS.enc.Base64.parse(data)
        }), this.key, {
                iv: this.ivKey,
                mode: CryptoJS.mode.CBC
            }).toString(CryptoJS.enc.Utf8);
        var decryptedParse = JSON.parse(decryptedData);    
        return decryptedParse;
    }

    padString(source) {
        var paddingChar = ' ';
        var size = 16;
        var x = source.length % size;
        var padLength = size - x;

        for (var i = 0; i < padLength; i++) source += paddingChar;

        return source;
    }

}