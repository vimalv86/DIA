import { Injectable } from "@angular/core";

@Injectable()
export class Constants {
    private MESSAGES: Object = {
        borrowerVal: 'Not for Users',
        successMsg: 'Record saved sucessfully',
        errorMsg: '500: Please check internet connectivity',
        emailVal: 'Enter correct E-mail ID',
        pinCodeVal: 'Enter correct pin code',
        mobileNoVal: 'Enter correct mobile number',
        panVal: 'Enter correct PAN card number',
        requiredFieldVal: 'Please enter all required fields to save the data',
        unitDetailVal: 'Enter unit details',
        submitSuccess: 'Submitted successfully',
        PFIDVal: 'Invalid user ID',
        LOSDataError: 'Enter correct LOS number',
        DateVal: 'To Date should be greater than From Date',
        delPopUpMsg : 'Confirm to delete the liability',
        liabilityDelSuccMsg: 'Laibility deleted successfully',
        liabilityDelFailMsg: 'Not able to clear liability data. Please try again later',
        PFIDValManageReview: 'Invalid PF ID',
        addReviewerVal: 'Max 3 reviewer permitted',
        inspectorVal: 'Please try with other PFID to proceed',
        removeReviewerVal: 'Confirm to delete the Reviewer',
        reviewerIDVal: 'Reviewer is already added',
        changeReviewerVal: 'Choose atleast one checkbox to proceed',
        reviewerAddVal: 'No permission to add this user.',
        submitInspectVal: 'Please fill the required field and submit',
        inspectionSubmitSuccess: 'Completed successfully',
        LOSVal: 'Enter correct LOS number',
        LOSLength: 'Enter correct LOS number',
        BranchLength: 'Enter valid Branch Code',
        LandLineNoVal: 'Please enter valid Land Line number',
        AmountVal: 'Invalid Amount',
        AccountNoVal: 'Invalid Account Number',
        LimitVal: 'Invalid Limit Sanctioned Amount',
        MarketVal: 'Invalid Market Value Amount',
        AdvancedVal: 'Invalid Advanced Value Amount',
        DrawingVal: 'Invalid Drawing Power Amount',
        OutstandingVal: 'Invalid Outstanding Amount',
        DateValLimit: 'Maximum 90 days of limit can be selected',
        rejectVal: 'Exceed max limit of rejection',
        dataVal: 'Data not available',
    };

    getMessage(message: string) : string {
        return this.MESSAGES[message];
    }
}