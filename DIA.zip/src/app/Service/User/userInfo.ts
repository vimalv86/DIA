export class UserInfo {
    pfId: number;
}