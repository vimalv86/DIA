import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

import { DIAConfig } from '../../../../Shared/config';

@Injectable()
export class SmePostsanctionIncompleteService {
    url = DIAConfig.apiUrl + "/smepost/getincompleteitems";
    constructor(private http: Http) { }

    public getSmeIncomplete(data:any): Observable<any> {
        return this.http.post(this.url, data, null)
            .map(response => {
                let result: any = response.json();
                return result;
            })
            .catch(response => {
                return "Error";
            });

    }
}