export class SmeSearchLoan {
    appId: string;
    losNum: number;
    executivePFIndex: number;
}