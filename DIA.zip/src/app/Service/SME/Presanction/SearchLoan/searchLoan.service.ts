import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { CryptoService } from '../../../../Shared/UtilsService/crypto.service';
import { SmeSearchLoan } from './searchLoan';

import { DIAConfig } from '../../../../Shared/config';

@Injectable()
export class SmePresanctionSearchLoanService {
    //  losUrl = DIAConfig.apiUrl + "/smepre/getlosdetails/";
    losUrl = "https://mobile.onlinesbi.com/diauat/smepre/getLOSServiceDetails";
    //losUrl = DIAConfig.apiUrl + "/smepre/getLOSServiceDetails";
    // branchUrl = DIAConfig.apiUrl + "/smepre/searchlos/";
    //branchUrl = DIAConfig.apiUrl + "/smepre/getLOSServiceDetailsWithDate/";
    branchUrl = "https://mobile.onlinesbi.com/diauat/smepre/getLOSServiceDetailsWithDate/";
    constructor(private http: Http, private cryptoService: CryptoService) { }

    public getSmeSearchLoanWithLOS(data: any): Observable<any> {
         this.cryptoService.generateKey(localStorage.getItem("pfID"));
         this.cryptoService.generateIVKey(localStorage.getItem("pfID"));
        var encryptedData = "";
        var isEncryptionEnabled = localStorage.getItem("isEncryptionEnabled");
        if (isEncryptionEnabled == "true") {
            var headers = new Headers();
            var headers = new Headers({ 'Content-Type': 'application/json' });
            headers.append('token', localStorage.getItem("PFIDEncrypted"));
            encryptedData = this.cryptoService.encryptData(data);
        } else {
            encryptedData = data;
        }
        return this.http.post(this.losUrl, encryptedData, { headers: headers })
            .map(response => {
                var responseData = "";
                if (isEncryptionEnabled == "true") {
                    responseData = this.cryptoService.decryptData(response.text());
                } else {
                    responseData = response.json();
                }
                return responseData;
            })
            .catch(response => {
                return "Error";
            });

    }

    public getSmeSearchLoanWithBranch(data: any): Observable<any> {
        var encryptedData = "";
         this.cryptoService.generateKey(localStorage.getItem("pfID"));
         this.cryptoService.generateIVKey(localStorage.getItem("pfID"));
        var isEncryptionEnabled = localStorage.getItem("isEncryptionEnabled");
        if (isEncryptionEnabled == "true") {
            var headers = new Headers();
            var headers = new Headers({ 'Content-Type': 'application/json' });
            headers.append('token', localStorage.getItem("PFIDEncrypted"));
            encryptedData = this.cryptoService.encryptData(data);
        } else {
            encryptedData = data;
        }
        return this.http.post(this.branchUrl, encryptedData, { headers: headers })
            .map(response => {
                var responseData = "";
                if (isEncryptionEnabled == "true") {
                    responseData = this.cryptoService.decryptData(response.text());
                } else {
                    responseData = response.json();
                }
                return responseData;
            })
            .catch(response => {
                return "Error";
            });

    }
}