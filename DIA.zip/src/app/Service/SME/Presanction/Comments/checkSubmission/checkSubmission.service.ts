import { HttpModule, Http, Response } from '@angular/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map'
import { Comments } from '../comments';
import { CryptoService } from '../../../../../Shared/UtilsService/crypto.service';
import { Headers, RequestOptions } from '@angular/http';
import { DIAConfig } from '../../../../../Shared/config';

@Injectable()
export class CheckSubmissionService {
    http: Http;
    posts_Url: string = DIAConfig.apiUrl + '/smepre/presubmissioncheck';
    constructor(public _http: Http, private cryptoService: CryptoService) {
        this.http = _http;
    }
    postComment(data: any) {
        var encryptedData = "";
        var isEncryptionEnabled = localStorage.getItem("isEncryptionEnabled");
        if (isEncryptionEnabled == "true") {
            var headers = new Headers();
            var headers = new Headers({ 'Content-Type': 'application/json' });
            headers.append('token', localStorage.getItem("PFIDEncrypted"));
            encryptedData = this.cryptoService.encryptData(data);
        } else {
            encryptedData = data;
        }
        return this.http.post(this.posts_Url, encryptedData, { headers: headers })
            .map(response => {
                 var responseData = "";
                 if (isEncryptionEnabled == "true") {
                     responseData = this.cryptoService.decryptData(response.text());
                 }else{
                     responseData = response.json();
                 }
                return responseData;
            })
            .catch(response => {
                return "Error";
            });
    }
}		