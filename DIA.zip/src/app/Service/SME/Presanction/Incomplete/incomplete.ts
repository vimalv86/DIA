export class SmeIncomplete {
    loanNum: string = null;
    unitName: string = null;
    initiationDateTS: string = null;
    pendingSinceTS: string = null;
    lastvisitdate: string = null;
    //complete: string = null;
    //delete: string = null;
}