import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { CryptoService } from '../../../../Shared/UtilsService/crypto.service';
import { DIAConfig } from '../../../../Shared/config';

@Injectable()
export class SmeSearchReportsGetInspectionDetailsService {
    url = DIAConfig.apiUrl + "/sme/getinspectiondetails";
    constructor(private http: Http, private cryptoService: CryptoService) { }

    public getInspectionDetails(data: any): Observable<any> {
        var encryptedData = "";
        var isEncryptionEnabled = localStorage.getItem("isEncryptionEnabled");
        if (isEncryptionEnabled == "true") {
            var headers = new Headers();
            var headers = new Headers({ 'Content-Type': 'application/json' });
            headers.append('token', localStorage.getItem("PFIDEncrypted"));
            encryptedData = this.cryptoService.encryptData(data);
        } else {
            encryptedData = data;
        }
        return this.http.post(this.url, encryptedData, { headers: headers })
            .map(response => {
                var responseData = "";
                if (isEncryptionEnabled == "true") {
                    responseData = this.cryptoService.decryptData(response.text());
                } else {
                    responseData = response.json();
                }
                return responseData;
            })
            .catch(response => {
                return "Error";
            });

    }
}