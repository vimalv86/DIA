import { Component } from '@angular/core';

@Component({
    selector: 'footer-nav',
    templateUrl: './footerNavigation.component.html',
    styleUrls: ['./footerNavigation.component.scss']
})

export class FooterNavigationComponent {
    
}