import { Component } from '@angular/core';

@Component({
    selector: 'asideNav',
    templateUrl: './asideNavigation.component.html',
    styleUrls: ['./asideNavigation.component.scss']
})

export class AsideNavigationComponent {
    
}