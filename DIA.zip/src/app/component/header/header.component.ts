import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';

import { DIAUserInfoService } from '../../Service/User/userInfo.service';
import { GetNotificationService } from '../../Service/User/Notification/GetNotification/getNotification.service';
import { UpdateNotificationService } from '../../Service/User/Notification/UpdateNotification/updateNotification.service';
import { SmePresanctionSearchLoanService } from '../../Service/SME/Presanction/SearchLoan/searchLoan.service';
import { UserInfo } from '../../Service/User/userInfo';
import { CryptoService } from '../../Shared/UtilsService/crypto.service';
import { Cookie } from 'ng2-cookies/ng2-cookies';
import { Observable } from 'rxjs/Rx';
declare var RSAKey: any;
declare var CryptoJS: any;

@Component({
  selector: 'dia-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  providers: [
    UserInfo,
    DIAUserInfoService,
    GetNotificationService,
    UpdateNotificationService,
    SmePresanctionSearchLoanService  
    ]
})
export class HeaderComponent implements OnInit {
  private apiRequest: any;
  private apiRequestForNotification: any;
  private pfId: any;
  private password: string;
  private message: string;
  private notification: any;
  private apiRequestForUpdateNotification: any;
  private PFIDArrayBuf: any;
  private encryptedData: any;
  private decryptedData: any;
  private privateKeyData: any;

  constructor(private router: Router, private service: DIAUserInfoService, private route: ActivatedRoute, private notificationService: GetNotificationService, private updateNotificationService: UpdateNotificationService, private searchService: SmePresanctionSearchLoanService, private cryptoService: CryptoService) {
  }

  /*
  This function is called when component loads
  */    
  @Input() userInfo: UserInfo;
  ngOnInit() {
    this.userInfo = new UserInfo();
    localStorage.setItem("pfID", null);
    // if (Cookie.get('PFID') && Cookie.get('PFID') != null && Cookie.get('PFID') != "null") {
    // this.pfId = Cookie.get('PFID');
    this.pfId = 1100024;
    this.apiRequest = { "pfId": this.pfId, "invokedFrom": "login"};
    localStorage.setItem("pfID", this.pfId);
    localStorage.setItem("isEncryptionEnabled", "true");
    this.generateRSAKey();
    this.cryptoService.generateKey(this.pfId);
    this.cryptoService.generateIVKey(this.pfId);
    this.service.getUserInfo(this.apiRequest).subscribe(response => {
      if (response.responseCode == 200) {
        if (response && response.userDetails) {
          if (response.userDetails.role == 4) {
            this.userInfo = response;
            localStorage.setItem("userDetails", null);
            localStorage.setItem("userDetails", JSON.stringify(this.userInfo));
          } else {
            this.message = "You don't have access to DIA Application, Please raise a request in DIA User Management Portal";
          }
        } else {
          localStorage.setItem("userDetails", null);
          this.message = "You don't have access to DIA Application, Please raise a request in DIA User Management Portal";
        }
      } else {
        localStorage.setItem("userDetails", null);
        this.message = response.responseMessage;
      }
    })
    // } else {
    //   localStorage.setItem("userDetails", null);
    //   this.message = "You don't have access to DIA Application, Please raise a request in DIA User Management Portal";
    // }
    this.getNotification();
  }

  /*
  This function is used to load the notification messages
  */
  getNotificationOnlyOnce() {
    this.apiRequestForNotification = { "appId": "WEB-DIA", "executivePFIndex": this.pfId };
    this.notificationService.getNotificationDetails(this.apiRequestForNotification).subscribe(response => {
      if (response) {
        this.notification = response;
      }
    })
  }

  /*
  This function is used to load the notification messages in every minute
  */
  getNotification() {
    this.getNotificationOnlyOnce();
    this.apiRequestForNotification = { "appId": "WEB-DIA", "executivePFIndex": this.pfId };
    Observable.interval(1000 * 60).subscribe(x => {
      this.notificationService.getNotificationDetails(this.apiRequestForNotification).subscribe(response => {
        this.notification = response;
      })
    });
  }

  /*
  This function is called when user clicked on the notification
  */
  updateNotification(notificationId) {
    this.apiRequestForUpdateNotification = { "appId": "WEB-DIA", "executivePFIndex": this.pfId, "id": notificationId }
    this.updateNotificationService.updateNotification(this.apiRequestForUpdateNotification).subscribe(response => {
      if (response) {
        this.getNotificationOnlyOnce();
        this.notification = response;
      }
    })
  }

  /*
  This function is used to redirect the page when user clicked on notification
  */
  notificationRedirect(notificationData) {
    this.updateNotification(notificationData.id);
  }

  /*
  This function is used to search the loan using LOS no
  */
  getSmeSearchLoanWithLOS() {
    let apiLOSRequest = { "executivePFIndex": this.pfId, "key": JSON.parse(localStorage.getItem("loanNo")) };
    this.searchService.getSmeSearchLoanWithLOS(apiLOSRequest).subscribe(response => {
      if (response.responseCode == 200) {
        if (!response.inspectionId) {
          localStorage.setItem("loanDetailsWithOutInspection", JSON.stringify(response));
        }
      } else {
        console.log("Error");
      }
      this.router.navigate(['/sme/presanctionDetail']);
    })
  }

  /*
  This function is used when user clicked on logout button
  */
  logout() {
    console.log("logut");
    localStorage.setItem("pfID", null);
    localStorage.setItem("userDetails", null);
    localStorage.setItem("borrowerRefID", null);
    localStorage.setItem("loanNo", null);
    localStorage.setItem("inspectionID", null);
    localStorage.setItem("isLoanEditable", null);
    localStorage.setItem("isCollateralEditable", null);
    localStorage.setItem("registredAddressUnit", null);
    localStorage.setItem("salutationAddress", null);
    Cookie.set('PFID', null);
    window.location.href = 'https://10.209.74.71:7002/diauiuat/logout';
  }

  /*
  This function is used to generate the RSA Key
  */
  generateRSAKey() {
    var rsa = new RSAKey();
    rsa.setPublic("9e1523cb4734682ee68a700344a2c1e939ee974f1863056834143125ecf340d5daef445f8c92fcc13abf84a777e4e4cc729be6a6c5a1b8fe745e4ad3fcc271ecdc82619dfd86925a45dc435674ec05ca5d19fd6652db3c7246f5cf34a4aac965f6e5d8ead541cf27ad992d6a71080a271ad6f3a3c1cf6fbb2d40700c4d5e3ed5", "10001");
    var res = rsa.encrypt(this.pfId.toString());
    var resString = CryptoJS.enc.Hex.parse(res).toString(CryptoJS.enc.Base64);
    localStorage.setItem("PFIDEncrypted", resString);
   }
}