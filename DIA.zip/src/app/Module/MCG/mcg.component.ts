import { Component } from '@angular/core';

@Component({
    selector: 'mcg',
    templateUrl: './mcg.component.html',
    styleUrls: ['./mcg.component.scss']
})

export class McgComponent {
    
}