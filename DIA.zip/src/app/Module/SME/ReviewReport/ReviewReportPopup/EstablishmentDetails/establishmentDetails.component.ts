import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';

import { Constants } from '../../../../../Shared/Constants/constants.service';
import { SmePresanctionGetEstablishmentListService } from '../../../../../Service/SME/ReviewReport/EstablishmentDetails/GetEstablishmentDetails/getEstablishmentDetails.service';

@Component({
  selector: 'popupEstablishmentDetails',
  templateUrl: './establishmentDetails.component.html',
  styleUrls: ['./establishmentDetails.component.scss', '../../../../module.component.scss'],
  providers: [
    SmePresanctionGetEstablishmentListService,
    Constants
  ]
})

export class PopupEstablishmentDetailsComponent {
  //private loanNumber: string;
  private inspectionID: string;
  private apiRequest: object;
  private pfId: string;
  private statusMsg: string;
  private executivePFIndex: any;
  private establishmentList: any;
  private establishmentDetail: any;
  private establishmentNo: any;
  private images: any[];
  private noData: boolean = true;

  constructor(private route: ActivatedRoute, private router: Router, private service: SmePresanctionGetEstablishmentListService, private constants: Constants) { }
  /**
  This function is called when component loads
  */
  ngOnInit() {
    this.route
      .params
      .subscribe(params => {
        this.establishmentNo = params['establishmentNo'];
        if (localStorage.getItem("userDetails") != null && localStorage.getItem("userDetails") != "null") {
          this.executivePFIndex = JSON.parse(localStorage.getItem("userDetails"));
          this.pfId = this.executivePFIndex.user.pfId.toString();
        }
        if (localStorage.getItem("inspectionID") != null && localStorage.getItem("inspectionID") != "null") {
          // this.loanNumber = JSON.parse(localStorage.getItem('loanNo'));
          this.inspectionID = JSON.parse(localStorage.getItem("inspectionID"));
          this.apiRequest = { "appId": "WEB-DIA", "executivePFIndex": this.pfId, "key": this.inspectionID };
          this.service.getEstablishmentList(this.apiRequest).subscribe(response => {
            if (response.establishmentWebVOList.length > 0) {
              this.noData = false;
              this.images = [];
              this.establishmentList = response.establishmentWebVOList;
              this.establishmentDetail = this.establishmentList[this.establishmentNo];
              if (this.establishmentDetail.imageList.length > 0) {
                for (let k = 0; k < this.establishmentDetail.imageList.length; k++) {
                  let latitudeAndLongitude = "Latitude: " + this.establishmentDetail.imageList[k].imageLatitude + ", " + "Longitude: " + this.establishmentDetail.imageList[k].imageLongitude;
                  this.images.push({ source: this.establishmentDetail.imageList[k].imagePath, alt: latitudeAndLongitude });
                }
              }
            } else {
              this.noData = true;
            }
          })
        }
      });
  }
}
