import { Router } from '@angular/router';
import { Component, OnInit, ViewChild } from '@angular/core';

import { ReviewReport } from '../../../Service/SME/ReviewReport/reviewReport';
import { DataTable } from 'primeng/components/datatable/datatable';

import { SmeSearchGetSearchReportsService } from '../../../Service/SME/SearchReport/GetSearchReports/getSearchReports.service';
import { UtilsService } from '../../../Shared/UtilsService/utils.service';
import { Constants } from '../../../Shared/Constants/constants.service';

@Component({
    selector: 'searchReport',
    templateUrl: './searchReport.component.html',
    styleUrls: ['./searchReport.component.scss', '../../module.component.scss'],
    providers: [
        ReviewReport,
        SmeSearchGetSearchReportsService,
        UtilsService,
        Constants
    ]
})

export class SearchReportComponent implements OnInit {
    private appUrl: string;
    private items: any[];
    private reviewList: any[];
    private pfId: any;
    private executivePFIndex: any;
    private message: string;
    private inspectionTypeList: any;
    private rangeDates: any;
    private searchBranchVal: any;
    private searchPfIdVal: any;
    private searchUnitName: any;
    private searchLosVal: any;
    private reviewListDupl: any;
    private selectedRange: any;
    private LOSVal: boolean = false;
    private unitVal: boolean = false;
    private branchVal: boolean = false;
    private pfIdVal: boolean = false;

    constructor(private router: Router, private getSearchReportService: SmeSearchGetSearchReportsService, private constants: Constants, private utilsService: UtilsService) { }

    @ViewChild(DataTable) dataTable: DataTable;

    searchLosCol(value: any, field, filterMatchMode) {
        this.dataTable.filter(value, field, filterMatchMode);
    }
    searchUnitNameCol(value: any, field, filterMatchMode) {
        this.dataTable.filter(value, field, filterMatchMode);
    }
    searchBranchCol(value: any, field, filterMatchMode) {
        this.dataTable.filter(value, field, filterMatchMode);
    }
    searchPfIdCol(value: any, field, filterMatchMode) {
        this.dataTable.filter(value, field, filterMatchMode);
    }

    /**
    This function is called when user clicked on the input fields
    @param data - input validation case
    @param field - field name
    @return data - input validation case
    */
    keypressCheck(data, field) {
        this.LOSVal = false;
        this.unitVal = false;
        this.branchVal = false;
        this.pfIdVal = false;
        switch (field) {
            case "LOS":
                if (this.utilsService.validString) {
                    this.LOSVal = true;
                } else {
                    this.LOSVal = false;
                }
                break;

            case "Unit":
                if (this.utilsService.validString) {
                    this.unitVal = true;
                } else {
                    this.unitVal = false;
                }
                break;

            case "Branch":
                if (this.utilsService.validString) {
                    this.branchVal = true;
                } else {
                    this.branchVal = false;
                }
                break;

            case "pfId":
                if (this.utilsService.validString) {
                    this.pfIdVal = true;
                } else {
                    this.pfIdVal = false;
                }
                break;
        }
        return data;
    }

    /**
    This function is called when component loads
    @return Nothing
    */
    ngOnInit() {
        if (localStorage.getItem("appUrl") != null) {
            this.appUrl = localStorage.getItem("appUrl").toString();
        }
        if (localStorage.getItem("userDetails") != "null" && localStorage.getItem("userDetails") != null) {
            this.executivePFIndex = JSON.parse(localStorage.getItem("userDetails"));
            this.pfId = this.executivePFIndex.user.pfId.toString();
        }
        this.getInspectionList();
        this.items = [
            { label: 'Home', url: this.appUrl + 'sme' },
            { label: 'Search Reports' }
        ];
    }

    /**
    This function is used for viewing the reports
    @params: details - inspection details
    @return Nothing
    */
    viewReport(details) {
        localStorage.setItem("borrowerRefID", null);
        localStorage.setItem("loanNo", null);
        localStorage.setItem("inspectionID", null);
        localStorage.setItem("borrowerRefID", JSON.stringify(details.borrowerRefId));
        localStorage.setItem("loanNo", JSON.stringify(details.losNum));
        localStorage.setItem("inspectionID", JSON.stringify(details.inspectionId));
        localStorage.setItem("inspectionType", JSON.stringify(details.inspectionType));
        this.router.navigate(['/sme/searchReport/searchReportPopup', { inspectionID: details.inspectionId, inspectionDate: details.inspectionDate }]);
    }

    /**
    This function is used for getting the inspection list
    @return Nothing
    */
    getInspectionList() {
        var objectToPost: { appId: any; executivePFIndex: any; } = { appId: "DIA", executivePFIndex: this.pfId };
        this.getSearchReportService.getSearchReportList(objectToPost).subscribe(
            data => {
                if (data.responseCode == 200) {
                    this.reviewList = data.rejectedList;
                    this.reviewListDupl = data.rejectedList;
                    this.inspectionTypeList = [];
                    this.inspectionTypeList.push({ label: "All", value: '' });
                    for (let k = 0; k < this.reviewList.length; k++) {
                        let reviewStatusObj = {
                            label: this.reviewList[k].inspectionType,
                            value: this.reviewList[k].inspectionType
                        }
                        this.inspectionTypeList.push(reviewStatusObj);
                    }
                    this.inspectionTypeList = this.inspectionTypeList.filter((object, index, duplicate) =>
                        index === duplicate.findIndex((t) => (
                            t.label === object.label
                        ))
                    )
                } else {
                    this.message = data.responseMessage;
                }
                this.setTimeOut();
            },
            err => {
                this.message = this.constants.getMessage('errorMsg');
                this.setTimeOut();
            },
            () => console.log('Request Completed')
        );
    }

    /**
    This function is used for selecting the date range
    @return Nothing
    */
    selectDateRange() {
        if (this.rangeDates[1]) {
            let startDate = new Date(this.rangeDates[0]);
            let endDate = new Date(this.rangeDates[1].getTime() + 60 * 60 * 24 * 1000).getTime();
            this.reviewList = this.reviewListDupl.filter(
                data => data.inspectionDate >= startDate && data.inspectionDate <= endDate);
        }
    }

    /**
    This function is used for clearing the filter
    @return Nothing
    */
    clearFilter() {
        this.searchLosVal = '';
        this.rangeDates = '';
        this.searchUnitName = '';
        this.searchBranchVal = '';
        this.searchPfIdVal = '';
        this.reviewList = this.reviewListDupl;
        this.selectedRange = '';
    }

    /**
    This function is used for setting the timeout
    @return Nothing
    */
    setTimeOut() {
        setTimeout(() => {
            this.message = "";
        }, 3000);
    }
}