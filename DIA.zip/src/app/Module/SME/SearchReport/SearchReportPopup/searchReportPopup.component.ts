import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'searchReportPopup',
  templateUrl: './searchReportPopup.component.html',
  styleUrls: ['./searchReportPopup.component.scss', '../../../module.component.scss']
})

export class SearchReportPopupComponent implements OnInit {
  private inspectionID : string;
  private inspectionDate: any;

  constructor(private router: Router, private route: ActivatedRoute) {

  }

  /**
  This function is called when component loads
  */
  ngAfterViewInit() {
    this.router.events.subscribe((event) => {
      const mainDiv = document.getElementById('review-report-popup');
      if (mainDiv) {
        mainDiv.scrollTop = 0;
      }
    });
  }

  /**
  This function is called when component loads
  */
  ngOnInit() {
    this.route
      .params
      .subscribe(params => {
        this.inspectionID = params['inspectionID'];
        this.inspectionDate = params['inspectionDate'];
      });
  }

  /**
  This function is used for closing the popup
  */
  closePopup() {
    this.router.navigate(['sme/searchReport']);
  }
}