import { Component } from '@angular/core';

@Component({
    selector: 'manageAccountTransfer',
    templateUrl: './manageAccountTransfer.component.html',
    styleUrls: ['./manageAccountTransfer.component.scss', '../../../module.component.scss']
})

export class ManageAccountTransfer {
    
}