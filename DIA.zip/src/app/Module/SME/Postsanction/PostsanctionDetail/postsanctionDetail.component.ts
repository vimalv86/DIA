import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';


@Component({
    selector: 'postsanctionDetail',
    templateUrl: './postsanctionDetail.component.html',
    styleUrls: ['./postsanctionDetail.component.scss'],
    providers: [
        
    ]
})

export class PostsanctionDetailComponent{
    
   
}