import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';

import { SmePostsanctionIncompleteService } from '../../../../Service/SME/Postsanction/Incomplete/incomplete.service';

@Component({
    selector: 'postsanctionIncomplete',
    templateUrl: './postsanctionIncomplete.component.html',
    styleUrls: ['./postsanctionIncomplete.component.scss', '../../../module.component.scss'],
     providers: [
        SmePostsanctionIncompleteService
    ]
})

export class PostsanctionIncompleteComponent implements OnInit{
    private loading: boolean;
    private apiRequest: any;
    private incompleteList: any[];
    private executivePFIndex: any;
    private pfId: string;
    private responseMessage: any;
    private timer: any;

    constructor(private service: SmePostsanctionIncompleteService,private router: Router, private route: ActivatedRoute) { }

    ngOnInit() {
        this.loading = true;
        window.scrollTo(0, 0);
        if (localStorage.getItem("userDetails") != "null" && localStorage.getItem("userDetails") != null) {
            this.executivePFIndex = JSON.parse(localStorage.getItem("userDetails"));
            if(this.executivePFIndex.user){
                this.pfId = this.executivePFIndex.user.pfId.toString();
                this.apiRequest = { "appId": "WEB-DIA", "executivePFIndex": this.pfId };
                this.service.getSmeIncomplete(this.apiRequest).subscribe(response => {
                    if (response.incompleteList) {
                      this.incompleteList = response.incompleteList;
                    }
                })
            }
        }
    }
}