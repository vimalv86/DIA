import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'postsanctionInspection',
    templateUrl: './postsanctionInspection.component.html',
    styleUrls: ['./postsanctionInspection.component.scss', '../../../module.component.scss'],
    providers: [
        
    ]
})

export class PostsanctionInspectionComponent {

}