import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'postsanctionDetails',
  templateUrl: './postsanctionDetails.component.html',
  styleUrls: ['./postsanctionDetails.component.scss', '../../../module.component.scss'],
  providers: [

  ]
})

export class PostsanctionDetailsComponent implements OnInit {
  private appUrl: string;
  private postSanctionBreadcrumb: any[];

  ngOnInit() {
    if (localStorage.getItem("appUrl") != null) {
      this.appUrl = localStorage.getItem("appUrl").toString();
    }
    this.postSanctionBreadcrumb = [
      { label: 'Home', url: this.appUrl + 'sme' },
      { label: 'Postsanction Inspection' }
    ];
  }
}