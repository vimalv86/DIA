import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';



@Component({
  selector: 'postsanctionUnitDetail',
  templateUrl: './postsanctionUnitDetail.component.html',
  styleUrls: ['./postsanctionUnitDetail.component.scss', '../../../../module.component.scss'],
  providers: [

  ]
})

export class PostsanctionUnitDetailComponent {

}
