import { Component } from '@angular/core';

@Component({
    selector: 'postsanctionBorrowerDetail',
    templateUrl: './postsanctionBorrowerDetail.component.html',
    styleUrls: ['./postsanctionBorrowerDetail.component.scss', '../../../module.component.scss']
})

export class PostsanctionBorrowerDetailComponent {
    
}