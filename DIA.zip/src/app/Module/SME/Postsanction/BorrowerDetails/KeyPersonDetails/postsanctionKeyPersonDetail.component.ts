import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'keyPersonDetail',
    templateUrl: './postsanctionKeyPersonDetail.component.html',
    styleUrls: ['./postsanctionKeyPersonDetail.component.scss', '../../../../module.component.scss'],
    providers: [

    ]
})


export class PostsanctionKeyPersonDetailComponent {
    
}