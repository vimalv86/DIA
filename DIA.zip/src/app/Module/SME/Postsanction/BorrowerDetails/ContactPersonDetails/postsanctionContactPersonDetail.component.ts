import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'contactPersonDetail',
    templateUrl: './postsanctionContactPersonDetail.component.html',
    styleUrls: ['./postsanctionContactPersonDetail.component.scss', '../../../../module.component.scss'],
    providers: [
    ]
})

export class PostsanctionContactPersonDetailComponent {
    
}
