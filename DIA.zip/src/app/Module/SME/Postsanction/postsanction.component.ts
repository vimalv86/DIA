import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'postsanction',
    templateUrl: './postsanction.component.html',
    styleUrls: ['./postsanction.component.scss', '../../module.component.scss']
})

export class PostsanctionComponent implements OnInit {
    private appUrl:string;
    private postSanctionBreadcrumb: any[];
    
    ngOnInit() {
        if(localStorage.getItem("appUrl") != null) {
            this.appUrl = localStorage.getItem("appUrl").toString();
        }
        this.postSanctionBreadcrumb = [
            {label:'Home', url: this.appUrl + 'sme'},
            {label:'Postsanction Inspection'}
        ];
    }
}