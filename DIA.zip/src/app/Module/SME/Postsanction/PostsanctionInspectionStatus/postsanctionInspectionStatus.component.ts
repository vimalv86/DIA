import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';

import { DIAConstants } from '../../../../Shared/constants';
import { SmePostsanctionInspectionStatusService } from '../../../../Service/SME/Postsanction/InspectionStatus/inspectionStatus.service';

@Component({
    selector: 'postsanctionInspectionStatus',
    templateUrl: './postsanctionInspectionStatus.component.html',
    styleUrls: ['./postsanctionInspectionStatus.component.scss', '../../../module.component.scss'],
    providers: [
        SmePostsanctionInspectionStatusService
    ]
})

export class PostsanctionInspectionStatusComponent implements OnInit {
    private loading: boolean;
    private apiRequest: any;
    private rejectedList: any[];
    private reviewStatus: any[];
    private executivePFIndex: any;
    private pfId: string;
    private isDisabled: boolean;

    constructor(private service: SmePostsanctionInspectionStatusService, private router: Router, private route: ActivatedRoute) {
        this.reviewStatus = DIAConstants.reviewStatus;
    }

        ngOnInit() {
        this.loading = true;
        window.scrollTo(0, 0);
        if (localStorage.getItem("userDetails") != "null" && localStorage.getItem("userDetails") != null) {
            this.executivePFIndex = JSON.parse(localStorage.getItem("userDetails"));
            if (this.executivePFIndex.user) {
                this.pfId = this.executivePFIndex.user.pfId.toString();
                this.apiRequest = { "appId": "WEB-DIA", "executivePFIndex": this.pfId };
                this.service.getSmeInspectionStatus(this.apiRequest).subscribe(response => {
                    if (response.inspectionList) {
                        this.isDisabled = false;
                        this.rejectedList = response.inspectionList;
                        this.reviewStatus = [];
                        this.reviewStatus.push({ label: "All Inspections", value: '' });
                        for (let k = 0; k < this.rejectedList.length; k++) {
                          if(this.rejectedList[k].reviewStatus == 'PendingForReview') {
                            this.rejectedList[k].reviewStatus = 'Pending For Review';
                          }
                          if(this.rejectedList[k].reviewStatus == 'WebIncomplete') {
                            this.rejectedList[k].reviewStatus = 'Web Incomplete';
                          }
                          if(this.rejectedList[k].reviewStatus == 'MobIncomplete') {
                            this.rejectedList[k].reviewStatus = 'Mob Incomplete';
                          }
                            let reviewStatusObj = {
                                label: this.rejectedList[k].reviewStatus,
                                value: this.rejectedList[k].reviewStatus
                            }
                            this.reviewStatus.push(reviewStatusObj);
                        }
                        this.reviewStatus = this.reviewStatus.filter((object, index, duplicate) =>
                            index === duplicate.findIndex((t) => (
                                t.label === object.label
                            ))
                        )                        
                    } else {
                        this.isDisabled = true;
                    }
                })
            }
        }
    }

}