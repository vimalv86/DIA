import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'postsanction-new',
    templateUrl: './postsanctionNew.component.html',
    styleUrls: ['./postsanctionNew.component.scss', '../../../module.component.scss'],
    providers: [
  
    ]
})

export class PostsanctionNewComponent {
  constructor(private router: Router) { }
  navigate() {
    this.router.navigate(['/sme/postsanctionDetails/postsanctionBorrowerDetails/unitDetails']);
  }
}