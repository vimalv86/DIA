import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';

import { DIAConstants } from '../../../../Shared/constants';

import { SmeInspectionStatus } from '../../../../Service/SME/Presanction/InspectionStatus/inspectionStatus';
import { SmePresanctionInspectionStatusService } from '../../../../Service/SME/Presanction/InspectionStatus/inspectionStatus.service';
import { DataTable } from 'primeng/components/datatable/datatable';


import { UtilsService } from '../../../../Shared/UtilsService/utils.service';
import { Constants } from '../../../../Shared/Constants/constants.service';

@Component({
    selector: 'presanctionInspection',
    templateUrl: './presanctionInspectionStatus.component.html',
    styleUrls: ['./presanctionInspectionStatus.component.scss', '../../../module.component.scss'],
    providers: [
        SmeInspectionStatus,
        SmePresanctionInspectionStatusService,
        UtilsService,
        Constants
    ]
})


export class PresanctionInspectionStatusComponent implements OnInit {
    private loading: boolean;
    private apiRequest: any;
    private rejectedList: any[];
    private reviewStatus: any[];
    private executivePFIndex: any;
    private pfId: string;
    private isDisabled: boolean;
    private LOSVal: boolean = false;
    private LOSValBlur: boolean = false;
    private onlyNumber: string;
    private validationMsg: any;
    private losNumber: any;
    private RefVal: any;

    constructor(private service: SmePresanctionInspectionStatusService, private utilsService: UtilsService, private router: Router, private route: ActivatedRoute) {
        this.reviewStatus = DIAConstants.reviewStatus;
    }

    @Input() smeInspectionStatus: SmeInspectionStatus;
    @ViewChild(DataTable) dataTable: DataTable;

    searchRefCol(value: any, field, filterMatchMode) {
      this.dataTable.filter(value, field, filterMatchMode);
    }
    searchLosCol(value: any, field, filterMatchMode) {
      this.dataTable.filter(value, field, filterMatchMode);
    }

    /**
    This function is called when user clicked on the input fields
    @param data - input validation case
    @param field - field name
    @return data - input validation case
    */
    keypressCheck(data, field) {
      this.LOSVal = false;
      this.RefVal = false;
      switch (field) {
          case "LOS":
              if (this.utilsService.validString) {
                  this.LOSVal = true;
              } else {
                  this.LOSVal = false;
              }
              break;

              case "Ref":
              if (this.utilsService.validString) {
                  this.RefVal = true;
              } else {
                  this.RefVal = false;
              }
              break;
      }
      return data;
  }

    /**
    This function is called when componet loads
    @return Nothing
    */
    ngOnInit() {
        this.loading = true;
        this.smeInspectionStatus = new SmeInspectionStatus();
        window.scrollTo(0, 0);
        if (localStorage.getItem("userDetails") != "null" && localStorage.getItem("userDetails") != null) {
            this.executivePFIndex = JSON.parse(localStorage.getItem("userDetails"));
            if (this.executivePFIndex.user) {
                this.pfId = this.executivePFIndex.user.pfId.toString();
                this.apiRequest = { "appId": "WEB-DIA", "executivePFIndex": this.pfId };
                this.service.getSmeInspectionStatus(this.apiRequest).subscribe(response => {
                    if (response.inspectionList) {
                        this.isDisabled = false;
                        this.rejectedList = response.inspectionList;
                        this.reviewStatus = [];
                        this.reviewStatus.push({ label: "All Inspections", value: '' });
                        for (let k = 0; k < this.rejectedList.length; k++) {
                          if(this.rejectedList[k].reviewStatus == 'PendingForReview') {
                            this.rejectedList[k].reviewStatus = 'Pending For Review';
                          }
                          if(this.rejectedList[k].reviewStatus == 'WebIncomplete') {
                            this.rejectedList[k].reviewStatus = 'Web Incomplete';
                          }
                          if(this.rejectedList[k].reviewStatus == 'MobIncomplete') {
                            this.rejectedList[k].reviewStatus = 'Mob Incomplete';
                          }
                            let reviewStatusObj = {
                                label: this.rejectedList[k].reviewStatus,
                                value: this.rejectedList[k].reviewStatus
                            }
                            this.reviewStatus.push(reviewStatusObj);
                        }
                        this.reviewStatus = this.reviewStatus.filter((object, index, duplicate) =>
                            index === duplicate.findIndex((t) => (
                                t.label === object.label
                            ))
                        )                        
                    } else {
                        this.isDisabled = true;
                    }
                })
            }
        }
    }

    /**
    This function is called when user clicked on View Button
    @params: data - full details of the inspection in selected object
    @return Nothing
    */
    viewLOS(data) {
        localStorage.setItem("borrowerRefID", null);
        localStorage.setItem("loanNo", null);
        localStorage.setItem("inspectionID", null);
        localStorage.setItem("loanDetailsWithOutInspection", null);
        localStorage.setItem("UnitName", null);
        localStorage.setItem("borrowerRefID", JSON.stringify(data.borrowerRefId));
        localStorage.setItem("loanNo", JSON.stringify(data.losNum));
        localStorage.setItem("inspectionID", JSON.stringify(data.inspectionId));
        if (data.reviewStatus == "Pending For Review" || data.reviewStatus == "PendingForReview" || data.reviewStatus == "Accepted") {
            localStorage.setItem("isLoanEditable", "false");
            localStorage.setItem("isCollateralEditable", "false");
        } else {
            localStorage.setItem("isLoanEditable", "true");
            localStorage.setItem("isCollateralEditable", "true");
        }
        this.router.navigate(['/sme/presanctionDetail']);
    }
}