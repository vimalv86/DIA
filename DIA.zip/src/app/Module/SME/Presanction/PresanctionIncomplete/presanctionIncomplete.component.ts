import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';

import { SmeIncomplete } from '../../../../Service/SME/Presanction/Incomplete/incomplete';
import { SmePresanctionIncompleteService } from '../../../../Service/SME/Presanction/Incomplete/incomplete.service';
import { SmePresanctionSearchLoanService } from '../../../../Service/SME/Presanction/SearchLoan/searchLoan.service';
import { DataTable } from 'primeng/components/datatable/datatable';

import { UtilsService } from '../../../../Shared/UtilsService/utils.service';
import { Constants } from '../../../../Shared/Constants/constants.service';

@Component({
    selector: 'presanctionIncomplete',
    templateUrl: './presanctionIncomplete.component.html',
    styleUrls: ['./presanctionIncomplete.component.scss', '../../../module.component.scss'],
    providers: [
        SmeIncomplete,
        SmePresanctionIncompleteService,
        UtilsService,
        Constants
    ]
})

export class PresanctionIncompleteComponent implements OnInit {
    private loading: boolean;
    private apiRequest: any;
    private incompleteList: any[];
    private executivePFIndex: any;
    private pfId: string;
    private responseMessage: any;
    private timer: any;
    private LOSVal: boolean = false;
    private onlyNumber: string;
    private validationMsg: any;
    private losNumber: any;
    private RefVal: any;

    constructor(private searchService: SmePresanctionSearchLoanService, private constants: Constants, private service: SmePresanctionIncompleteService, private router: Router, private utilsService: UtilsService, private route: ActivatedRoute) { }

    @Input() smeIncomplete: SmeIncomplete;
    @ViewChild(DataTable) dataTable: DataTable;

    searchRefCol(value: any, field, filterMatchMode) {
        this.dataTable.filter(value, field, filterMatchMode);
    }
    searchLosCol(value: any, field, filterMatchMode) {
        this.dataTable.filter(value, field, filterMatchMode);
    }

    /**
    This function is called when user clicked on the input fields
    @param data - input validation case
    @param field - field name
    @return data - input validation case
    */
    keypressCheck(data, field) {
        this.LOSVal = false;
        this.RefVal = false;
        switch (field) {
            case "LOS":
                if (this.utilsService.validString) {
                    this.LOSVal = true;
                } else {
                    this.LOSVal = false;
                }
                break;

            case "Ref":
                if (this.utilsService.validString) {
                    this.RefVal = true;
                } else {
                    this.RefVal = false;
                }
                break;
        }
        return data;
    }

    /**
    This function is called when component loads
    @return data - input validation case
    */
    ngOnInit() {
        this.loading = true;
        this.smeIncomplete = new SmeIncomplete();
        window.scrollTo(0, 0);
        if (localStorage.getItem("userDetails") != "null" && localStorage.getItem("userDetails") != null) {
            this.executivePFIndex = JSON.parse(localStorage.getItem("userDetails"));
            if (this.executivePFIndex.user) {
                this.pfId = this.executivePFIndex.user.pfId.toString();
                this.apiRequest = { "appId": "WEB-DIA", "executivePFIndex": this.pfId };
                this.service.getSmeIncomplete(this.apiRequest).subscribe(response => {
                    if (response.incompleteList) {
                        this.incompleteList = response.incompleteList;
                        for (let k = 0; k < this.incompleteList.length; k++) {
                            if (this.incompleteList[k].loanStatus == 'WebIncomplete') {
                                this.incompleteList[k].loanStatus = 'Web Incomplete';
                            }
                            if (this.incompleteList[k].loanStatus == 'MobIncomplete') {
                                this.incompleteList[k].loanStatus = 'Mob Incomplete';
                            }
                        }
                    }
                })
            }
        }
    }

    /**
    This function is called when user clicked on the complete button
    @params: data - full details of the inspection
    */
    completeLOS(data) {
        localStorage.setItem("borrowerRefID", null);
        localStorage.setItem("loanNo", null);
        localStorage.setItem("inspectionID", null);
        localStorage.setItem("loanDetailsWithOutInspection", null);
        localStorage.setItem("UnitName", null);
        if (data.borrowerRefId) {
            localStorage.setItem("borrowerRefID", JSON.stringify(data.borrowerRefId));
        }
        localStorage.setItem("loanNo", JSON.stringify(data.losNum));
        localStorage.setItem("inspectionID", JSON.stringify(data.inspectionId));
        localStorage.setItem("isLoanEditable", "true");
        localStorage.setItem("isCollateralEditable", "false");
        this.getSmeSearchLoanWithLOS();
    }

    /**
    This function is used for getting the loan details using LOS No
    @return Nothing
    */
    getSmeSearchLoanWithLOS() {
        let apiLOSRequest = { "executivePFIndex": this.pfId, "key": JSON.parse(localStorage.getItem("loanNo")) };
        this.searchService.getSmeSearchLoanWithLOS(apiLOSRequest).subscribe(response => {
            if (response.responseCode == 200) {
                if (!response.inspectionId) {
                    localStorage.setItem("loanDetailsWithOutInspection", JSON.stringify(response));
                }
            } else {
                this.setTimeOut();
                this.responseMessage = response.responseMessage;
            }
            this.router.navigate(['/sme/presanctionDetail']);
        })
    }

    /**
    This function is used for setting the timeout
    @return Nothing
    */
    setTimeOut() {
        this.timer = setTimeout(() => {
            this.responseMessage = '';
        }, 3000);
    }
}