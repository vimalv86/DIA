import { Component } from '@angular/core';

@Component({
    selector: 'borrowerDetail',
    templateUrl: './borrowerDetail.component.html',
    styleUrls: ['./borrowerDetail.component.scss', '../../../module.component.scss']
})

export class BorrowerDetailComponent {
    
}