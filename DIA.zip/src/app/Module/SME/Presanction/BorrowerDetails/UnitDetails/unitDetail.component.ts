import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { DIAConstants } from '../../../../../Shared/constants';
import { Constants } from '../../../../../Shared/Constants/constants.service';

import { UnitDetails } from '../../../../../Service/SME/Presanction/BorrowerDetails/UnitDetails/unitDetails';
import { AddUpdateInspection } from '../../../../../Service/SME/Presanction/BorrowerDetails/UnitDetails/addUpdateInspection';
import { AddUnitDetailsService } from '../../../../../Service/SME/Presanction/BorrowerDetails/UnitDetails/AddUnitDetails/addUnitDetails.service';
import { AddUpdateInspectionService } from '../../../../../Service/SME/Presanction/BorrowerDetails/UnitDetails/AddUpdateInspection/addUpdateInspection.service';
import { SmePresanctionGetUnitDetailsService } from '../../../../../Service/SME/Presanction/BorrowerDetails/UnitDetails/GetUnitDetails/getUnitDetails.service';
import { UtilsService } from '../../../../../Shared/UtilsService/utils.service';
import { ValidationMessageService } from '../../../../../Shared/ValidationMsgs/validationMsg.service';

@Component({
  selector: 'unitDetail',
  templateUrl: './unitDetail.component.html',
  styleUrls: ['./unitDetail.component.scss', '../../../../module.component.scss'],
  providers: [
    AddUnitDetailsService,
    AddUpdateInspectionService,
    SmePresanctionGetUnitDetailsService,
    UtilsService,
    Constants,
    ValidationMessageService
  ]
})

export class UnitDetailComponent implements OnInit {
  private apiRequest: object;
  private states: any[];
  private upToFour: any[];
  private upToThree: any[];
  private constitution: any;
  private responseStatus: Object = [];
  private status: boolean;
  private dateOfEstablish: Date;
  private message: string;
  private statusMsg: string;
  private borrowerRefId: string;
  private executivePFIndex: any;
  private unitAddress: any = {};
  private registredAddressUnit: any = {};
  private timeStamp: any;
  private establishmentDate: any;
  private btnDisabled: boolean;
  private pfId: string;
  private isEmailValid: boolean = true;
  private guarantorDisable: boolean;
  private collateralDisable: boolean;
  private isLoanEditable: boolean;
  private isPinCodeValid: boolean = true;
  private isPanValid: boolean = true;
  private isMobileNumberValid: boolean = true;
  private isLandLineNumValid: boolean = true;
  private isCollateralDisabled: boolean = false;
  private loanDetailsWithOutInspection: any;
  private cityVal: boolean = false;
  private activityVal: boolean = false;
  private panVal: boolean = false;
  private districtVal: boolean = false;
  private blockVal: boolean = false;
  private nameUnitVal: boolean = false;
  private villageVal: boolean = false;
  private pincodeVal: boolean = false;
  private plotVal: boolean = false;
  private address1Val: boolean = false;
  private address2Val: boolean = false;
  private mobileVal: boolean = false;
  private landlineVal: boolean = false;
  private cityValBlur: boolean = false;
  private activityValBlur: boolean = false;
  private panValBlur: boolean = false;
  private nameUnitValBlur: boolean = false;
  private districtValBlur: boolean = false;
  private blockValBlur: boolean = false;
  private villageValBlur: boolean = false;
  private pincodeValBlur: boolean = false;
  private mobileValBlur: boolean = false;
  private landlineValBlur: boolean = false;
  private plotValBlur: boolean = false;
  private address1ValBlur: boolean = false;
  private address2ValBlur: boolean = false;
  private onlyNumber: string;
  private onlyAlphabet: string;
  private avoidSpecialChar: string;
  private currentDate: any;
  private validationMsg: any;
  private dataResponse: any = {};
  private addUpdateResponse: any = {};

  constructor(private _addUnitDetailsService: AddUnitDetailsService, private _addUpdateInspectionService: AddUpdateInspectionService, private service: SmePresanctionGetUnitDetailsService, private route: ActivatedRoute, private utilsService: UtilsService, private constants: Constants, private validationMessageService: ValidationMessageService) {
    this.states = DIAConstants.states;
    this.constitution = DIAConstants.constitution;
    this.upToFour = DIAConstants.upToFour;
    this.upToThree = DIAConstants.upToThree;
    this.establishmentDate = null;
    this.currentDate = new Date();
  }

  @Input() unitDetails: UnitDetails;

  /**
  This function is used for checking whether guarantor present or not
  @params: status - Guarantor status
  @return Nothing
  */
  guarantorPresent(status) {
    if (status == 1) {
      this.guarantorDisable = true;
      this.unitDetails.noOfGuarantors = "1";
    } else {
      this.unitDetails.noOfGuarantors = "";
      this.guarantorDisable = false;
    }
  }

  /**
  This function is used for checking whether collateral present or not
  @params: status - Collateral status
  @return Nothing
  */
  collateralIdentified(status) {
    if (status == 1) {
      this.collateralDisable = true;
      this.unitDetails.noOfKeyPerson = "1";
    } else {
      this.unitDetails.noOfKeyPerson = "";
      this.collateralDisable = false;
    }
  }

  /**
  This function is used for adding the borrower unit details
  @return Nothing
  */
  addUnitDetail() {
    //  if (this.unitDetails.nameOfUnit && this.unitDetails.activityOfUnit && this.unitDetails.panTan && this.unitDetails.plotBuildingFlatNum && this.unitDetails.addressLine1 && this.unitDetails.addressLine2 && this.unitDetails.city && this.unitDetails.pinCode && this.unitDetails.mobileNum && this.unitDetails.constitution && this.unitDetails.state && this.unitDetails.guarantorsPresent && this.unitDetails.collateralIdentified && this.unitDetails.chkCollateral) {
    if (this.unitDetails.emailId) {
      this.isEmailValid = this.utilsService.emailValidator(this.unitDetails.emailId);
    } else {
      this.isEmailValid = true;
    }
    if (this.unitDetails.pinCode) {
      if (this.unitDetails.pinCode.length < 6) {
        this.isPinCodeValid = false;
      } else if (this.unitDetails.pinCode.charAt(0) == '0') {
        this.isPinCodeValid = false;
      } else {
        this.isPinCodeValid = true;
      }
    } else {
      this.isPinCodeValid = true;
    }
    if (this.unitDetails.mobileNum) {
      if (this.unitDetails.mobileNum.length < 10) {
        this.isMobileNumberValid = false;
      } else if (this.unitDetails.mobileNum.charAt(0) == '0') {
        this.isMobileNumberValid = false;
      }
      else {
        this.isMobileNumberValid = true;
      }
    } else {
      this.isMobileNumberValid = true;
    }
    if (this.unitDetails.landlineNum) {
      if (this.unitDetails.landlineNum.length < 8) {
        this.isLandLineNumValid = false;
      }
      else {
        this.isLandLineNumValid = true;
      }
    } else {
      this.isLandLineNumValid = true;
    }
    if (this.unitDetails.panTan) {
      if (this.unitDetails.panTan.length < 10) {
        this.isPanValid = false;
      } else {
        this.isPanValid = true;
      }
    } else {
      this.isPanValid = true;
    }
    if (this.isMobileNumberValid && this.isPinCodeValid && this.isEmailValid && this.isPanValid && this.isLandLineNumValid) {
      if (this.establishmentDate) {
        let actualTime = this.establishmentDate;
        let timeStamp = new Date(actualTime).getTime().toString();
        this.unitDetails["dateOfEstablishTS"] = timeStamp;
      } else {
        this.unitDetails["dateOfEstablishTS"] = null;
      }
      if (!this.unitDetails["borrowerRefId"] && localStorage.getItem("borrowerRefID") != null && localStorage.getItem("borrowerRefID") != "null") {
        this.unitDetails["borrowerRefId"] = localStorage.getItem("borrowerRefID");
      }
      this.unitDetails = this.utilsService.dataSourceSave(this.unitDetails);
      if (this.unitDetails["noOfGuarantors"] == "") {
        this.unitDetails["noOfGuarantors"] = "0";
      }
      if (this.unitDetails["noOfKeyPerson"] == "") {
        this.unitDetails["noOfKeyPerson"] = "0";
      }
      var objectToPost: { borrowerUnit: object; appId: string; executivePFIndex: string; } = { borrowerUnit: this.unitDetails, appId: "WEB-DIA", executivePFIndex: this.pfId };

      this.addUnitAddress();

      this._addUnitDetailsService.postComment(objectToPost).subscribe(
        data => {
          this.dataResponse = data;
          if (this.dataResponse.responseMessage == "Successful") {
            this.registredAddressUnit = localStorage.setItem("registredAddressUnit", JSON.stringify(this.unitAddress));
            if (localStorage.getItem("borrowerRefID") == "null" || localStorage.getItem("borrowerRefID") == null) {
              this.addUpdateInspection = new AddUpdateInspection();
              this.borrowerRefId = this.dataResponse.refId;
              this.addInspectionDetail();
              this.addUpdateinspection();
            } else {
              this.message = this.constants.getMessage('successMsg');
              this.statusMsg = "success";
            }
          } else {
            this.message = this.dataResponse.responseMessage;
            this.statusMsg = "error";
          }
        },
        err => {
          console.log(err);
          this.message = this.constants.getMessage('errorMsg');
          this.statusMsg = "error";
        },
        () => console.log('Request Completed')
      );
      this.status = true;

      this.setTimeOut();
    } else {
      if (!this.isEmailValid) {
        this.message = this.constants.getMessage('emailVal');
        this.statusMsg = "error";
      } else if (!this.isPinCodeValid) {
        this.message = this.constants.getMessage('pinCodeVal');
        this.statusMsg = "error";
      } else if (!this.isMobileNumberValid) {
        this.message = this.constants.getMessage('mobileNoVal');
        this.statusMsg = "error";
      } else if (!this.isLandLineNumValid) {
        this.message = this.constants.getMessage('LandLineNoVal');
        this.statusMsg = "error";
      } else if (!this.isPanValid) {
        this.message = this.constants.getMessage('panVal');
        this.statusMsg = "error";
      }
      this.setTimeOut();
    }
    // } else {
    //   this.message = this.constants.getMessage('requiredFieldVal');
    //   this.statusMsg = "error";
    //   this.setTimeOut();
    // }
  }

  /**
  This function is used for setting the timeout
  @return Nothing
  */
  setTimeOut() {
    setTimeout(() => {
      this.message = "";
      this.onlyNumber = "";
      this.onlyAlphabet = "";
      this.avoidSpecialChar = "";
    }, 3000);
  }

  /**
  This function is used for adding the inspection details
  @return Nothing
  */
  addInspectionDetail() {
    let randomNum = Math.random().toString();
    let lastFive = randomNum.substr(randomNum.length - 5);
    let losNumber = this.executivePFIndex.user.brId.toString() + lastFive;
    this.addUpdateInspection["borrowerUnitId"] = this.borrowerRefId;
    this.addUpdateInspection["losNum"] = JSON.parse(localStorage.getItem("loanNo"));
    this.addUpdateInspection["executiveReviewerPFIndex"] = "12345";
    this.addUpdateInspection["accountNum"] = "123456";
    this.addUpdateInspection["branchCode"] = this.executivePFIndex.user.brId.toString();
    this.addUpdateInspection["conductedDateTS"] = new Date().getTime().toString();
  }

  /**
  This function is used for updating the inspection details
  @return Nothing
  */
  @Input() addUpdateInspection: AddUpdateInspection;
  addUpdateinspection() {
    var objectToPost: { loanInspectionStatusDetailsVO: object; appId: string; executivePFIndex: string; } = { loanInspectionStatusDetailsVO: this.addUpdateInspection, appId: "WEB-DIA", executivePFIndex: this.pfId };
    this._addUpdateInspectionService.postInspection(objectToPost).subscribe(
      data => {
        this.addUpdateResponse = data;
        if (this.addUpdateResponse.responseMessage == "Successful") {
          localStorage.setItem("borrowerRefID", this.borrowerRefId);
          localStorage.setItem("inspectionID", JSON.stringify(this.addUpdateResponse.refId));
          this.message = this.constants.getMessage('successMsg');
          this.statusMsg = "success";
        } else {
          this.message = this.addUpdateResponse.responseMessage;
          this.statusMsg = "error";
        }
      },
      err => {
        this.message = this.constants.getMessage('errorMsg');
        this.statusMsg = "error";
      },
      () => console.log('Request Completed')
    );
    this.status = true;
    this.setTimeOut();
  }

  /**
  This function is called when component loads
  @return Nothing
  */
  ngOnInit() {
    this.unitDetails = new UnitDetails();
    if (localStorage.getItem("isLoanEditable") != null && localStorage.getItem("isLoanEditable") != "null") {
      if (localStorage.getItem("isLoanEditable") == "true") {
        this.isLoanEditable = true;
      } else {
        this.isLoanEditable = false;
      }
    }
    if (localStorage.getItem("isCollateralEditable") != null && localStorage.getItem("isCollateralEditable") != "null") {
      if (localStorage.getItem("isCollateralEditable") == "true") {
        this.isCollateralDisabled = true;
      } else {
        this.isCollateralDisabled = false;
      }
    }
    if (localStorage.getItem("userDetails") != null && localStorage.getItem("userDetails") != "null") {
      this.executivePFIndex = JSON.parse(localStorage.getItem("userDetails"));
      this.pfId = this.executivePFIndex.user.pfId.toString();
    }
    if (localStorage.getItem("borrowerRefID") != null && localStorage.getItem("borrowerRefID") != "null") {
      this.borrowerRefId = JSON.parse(localStorage.getItem('borrowerRefID'));
      this.apiRequest = { "appId": "WEB-DIA", "executivePFIndex": this.pfId, "key": this.borrowerRefId };
      this.service.getUnitDetails(this.apiRequest).subscribe(response => {
        if (response.borrowerUnit) {
          this.unitDetails = response.borrowerUnit;
          this.unitDetails = this.utilsService.dataSourceCheck(this.unitDetails);
          if (!this.unitDetails.nameOfUnit) {
            if (JSON.parse(localStorage.getItem('UnitName'))) {
              this.unitDetails.nameOfUnit = JSON.parse(localStorage.getItem('UnitName'));
            }
          }
          if (this.unitDetails.collateralIdentified == "1") {
            this.collateralDisable = true;
          } else {
            this.collateralDisable = false;
          }
          if (this.unitDetails.guarantorsPresent == "1") {
            this.guarantorDisable = true;
          } else {
            this.guarantorDisable = false;
          }
          this.addUnitAddress();
          if (this.unitDetails.dateOfEstablishTS != null) {
            if (+this.unitDetails.dateOfEstablishTS == 0) {
              this.establishmentDate = null;
            } else {
              this.establishmentDate = new Date(this.unitDetails.dateOfEstablishTS);
            }
          } else {
            this.establishmentDate = null;
          }
        }
      })
    }
    else {
      this.loanDetailsWithOutInspection = JSON.parse(localStorage.getItem("loanDetailsWithOutInspection"));
      if (this.loanDetailsWithOutInspection) {
        if (this.loanDetailsWithOutInspection.borrowerDetails) {
          this.unitDetails = this.loanDetailsWithOutInspection.borrowerDetails;
          this.unitDetails = this.utilsService.dataSourceCheckFromLOS(this.unitDetails);
          this.setStateFromLOS(this.unitDetails.state);
          if (this.loanDetailsWithOutInspection.borrowerPersonalList && this.loanDetailsWithOutInspection.borrowerPersonalList.length > 0) {
            this.unitDetails["noOfKeyPerson"] = this.loanDetailsWithOutInspection.borrowerPersonalList.length;
            this.unitDetails["collateralIdentified"] = "1";
            this.unitDetails["noOfKeyPersonStatus"] = "LOS"
            this.unitDetails["collateralIdentifiedStatus"] = "LOS";
          }
          if (this.loanDetailsWithOutInspection.collateralList && this.loanDetailsWithOutInspection.collateralList.length > 0) {
            this.unitDetails["chkCollateral"] = "1";
            this.unitDetails["chkCollateralStatus"] = "LOS";
          }
          if (this.loanDetailsWithOutInspection.gurantorList && this.loanDetailsWithOutInspection.gurantorList.length > 0) {
            this.unitDetails["noOfGuarantors"] = this.loanDetailsWithOutInspection.gurantorList.length;
            this.unitDetails["guarantorsPresent"] = "1";
            this.unitDetails["noOfGuarantorsStatus"] = "LOS"
            this.unitDetails["guarantorsPresentStatus"] = "LOS";
          }
          if (!this.unitDetails.nameOfUnit) {
            if (JSON.parse(localStorage.getItem('UnitName'))) {
              this.unitDetails.nameOfUnit = JSON.parse(localStorage.getItem('UnitName'));
            }
          }
          delete this.unitDetails["borrowerRefId"];
          if (this.unitDetails.collateralIdentified == "1") {
            this.collateralDisable = true;
          } else {
            this.collateralDisable = false;
          }
          if (this.unitDetails.guarantorsPresent == "1") {
            this.guarantorDisable = true;
          } else {
            this.guarantorDisable = false;
          }
          this.addUnitAddress();
          // this.establishmentDate = null;
          if (this.unitDetails.dateOfEstablishTS != null) {
            if (+this.unitDetails.dateOfEstablishTS == 0) {
              this.establishmentDate = null;
            } else {
              this.establishmentDate = new Date(this.unitDetails.dateOfEstablishTS);
            }
          } else {
            this.establishmentDate = null;
          }
        } else {
          if (JSON.parse(localStorage.getItem('UnitName'))) {
            this.unitDetails.nameOfUnit = JSON.parse(localStorage.getItem('UnitName'));
          }
          delete this.unitDetails.field_status;
          delete this.unitDetails.field_statusMap;
          this.unitDetails = this.utilsService.dataSourceCheckFromLOS(this.unitDetails);
        }
      } else {
        delete this.unitDetails.field_status;
        delete this.unitDetails.field_statusMap;
        this.unitDetails = this.utilsService.dataSourceCheckFromLOS(this.unitDetails);
      }
      this.statusMsg = this.constants.getMessage('borrowerVal');
    }
    this.getValidationMessage();
  }

  /**
  This function is used for getting the validation message
  @return Nothing
  */
  getValidationMessage() {
    this.validationMessageService.getValidationMessage().subscribe(response => {
      if (response) {
        this.validationMsg = response;
      } else {
        console.log("Something worng");
      }
    })
  }

  /**
  This function is used for adding the unit details address
  @return Nothing
  */
  addUnitAddress() {
    this.unitAddress["plotBuildingFlatNum"] = this.unitDetails.plotBuildingFlatNum;
    this.unitAddress["addressLine1"] = this.unitDetails.addressLine1;
    this.unitAddress["addressLine2"] = this.unitDetails.addressLine2;
    this.unitAddress["state"] = this.unitDetails.state;
    this.unitAddress["city"] = this.unitDetails.city;
    this.unitAddress["district"] = this.unitDetails.district;
    this.unitAddress["blockTehsilSubdistrict"] = this.unitDetails.blockTehsilSubdistrict;
    this.unitAddress["village"] = this.unitDetails.village;
    this.unitAddress["pinCode"] = this.unitDetails.pinCode;
    this.unitAddress["mobileNum"] = this.unitDetails.mobileNum;
    this.unitAddress["landlineNum"] = this.unitDetails.landlineNum;
    this.unitAddress["emailId"] = this.unitDetails.emailId;
    this.registredAddressUnit = localStorage.setItem("registredAddressUnit", JSON.stringify(this.unitAddress));
  }

  /**
  This function is used for setting the state from LOS
  @params:stateName - State Name getting from LOS
  @return Nothing
  */
  setStateFromLOS(stateName) {
    switch (stateName) {
      case "06-HARYANA":
        this.unitDetails.state = "HARYANA"
        break;

      case "27-MAHARASHTRA":
        this.unitDetails.state = "MAHARASHTRA"
        break;

      case "08-RAJASTHAN":
        this.unitDetails.state = "RAJASTHAN"
        break;

      case "84-NCT OF DELHI":
        this.unitDetails.state = "NCT OF DELHI"
        break;

      case "09-UTTAR PRADESH":
        this.unitDetails.state = "UTTAR PRADESH"
        break;

      case "10-BIHAR":
        this.unitDetails.state = "BIHAR"
        break;

      case "12-ARUNACHAL PRADESH":
        this.unitDetails.state = "ARUNACHAL PRADESH"
        break;

      case "11-SIKKIM":
        this.unitDetails.state = "SIKKIM"
        break;

      case "13-NAGALAND":
        this.unitDetails.state = "NAGALAND"
        break;

      case "17-MEGHALAYA":
        this.unitDetails.state = "MEGHALAYA"
        break;

      case "15-MIZORAM":
        this.unitDetails.state = "MIZORAM"
        break;

      case "16-TRIPURA":
        this.unitDetails.state = "TRIPURA"
        break;

      case "14-MANIPUR":
        this.unitDetails.state = "MANIPUR"
        break;

      case "07-DELHI":
        this.unitDetails.state = "DELHI"
        break;

      case "18-ASSAM":
        this.unitDetails.state = "ASSAM"
        break;

      case "19-WEST BENGAL":
        this.unitDetails.state = "WEST BENGAL"
        break;

      case "20-JHARKHAND":
        this.unitDetails.state = "JHARKHAND"
        break;

      case "21-ODISHA":
        this.unitDetails.state = "ODISHA"
        break;

      case "22-CHHATTISGARH":
        this.unitDetails.state = "CHHATTISGARH"
        break;

      case "23-MADHYA PRADESH":
        this.unitDetails.state = "MADHYA PRADESH"
        break;

      case "24-GUJARAT":
        this.unitDetails.state = "GUJARAT"
        break;

      case "25-DAMAN AND DIU":
        this.unitDetails.state = "DAMAN AND DIU"
        break;

      case "26-DADRA  AND NAGAR HAVELI":
        this.unitDetails.state = "DADRA  AND NAGAR HAVELI"
        break;

      case "27-MAHARASHTRA":
        this.unitDetails.state = "MAHARASHTRA"
        break;

      case "28-ANDHRA PRADESH":
        this.unitDetails.state = "ANDHRA PRADESH"
        break;

      case "29-KARNATAKA":
        this.unitDetails.state = "KARNATAKA"
        break;

      case "31-LAKSHADWEEP":
        this.unitDetails.state = "LAKSHADWEEP"
        break;

      case "32-KERALA":
        this.unitDetails.state = "KERALA"
        break;

      case "33-TAMIL NADU":
        this.unitDetails.state = "TAMIL NADU"
        break;

      case "30-GOA":
        this.unitDetails.state = "GOA"
        break;

      case "34-PUDUCHERRY":
        this.unitDetails.state = "PUDUCHERRY"
        break;

      case "35-ANDAMAN  AND NICOBAR ISLANDS":
        this.unitDetails.state = "ANDAMAN  AND NICOBAR ISLANDS"
        break;

      case "02-HIMACHAL PRADESH":
        this.unitDetails.state = "HIMACHAL PRADESH"
        break;

      case "01-JAMMU  AND KASHMIR":
        this.unitDetails.state = "JAMMU  AND KASHMIR"
        break;

      case "03-PUNJAB":
        this.unitDetails.state = "PUNJAB"
        break;

      case "04-CHANDIGARH":
        this.unitDetails.state = "CHANDIGARH"
        break;

      case "05-UTTARAKHAND":
        this.unitDetails.state = "UTTARAKHAND"
        break;
    }
  }

  /**
  This function is called when user clicked on the input fields
  @param data - input validation case
  @param field - field name
  @return data - input validation case
  */
  keypressCheck(data, field) {
    this.cityVal = false;
    this.blockVal = false;
    this.activityVal = false;
    this.nameUnitVal = false;
    this.panVal = false;
    this.districtVal = false;
    this.villageVal = false;
    this.pincodeVal = false;
    this.mobileVal = false;
    this.landlineVal = false;
    this.plotVal = false;
    this.address1Val = false;
    this.address2Val = false;
    switch (field) {
      case "NameUnit":
        if (this.utilsService.validString) {
          this.nameUnitVal = true;
        } else {
          this.nameUnitVal = false;
        }
        break;

      case "Activity":
        if (this.utilsService.validString) {
          this.activityVal = true;
        } else {
          this.activityVal = false;
        }
        break;

      case "PAN":
        if (this.utilsService.validString) {
          this.panVal = true;
        } else {
          this.panVal = false;
        }
        break;

      case "City":
        if (this.utilsService.validString) {
          this.cityVal = true;
        } else {
          this.cityVal = false;
        }
        break;

      case "Block":
        if (this.utilsService.validString) {
          this.blockVal = true;
        } else {
          this.blockVal = false;
        }
        break;

      case "District":
        if (this.utilsService.validString) {
          this.districtVal = true;
        } else {
          this.districtVal = false;
        }
        break;

      case "Village":
        if (this.utilsService.validString) {
          this.villageVal = true;
        } else {
          this.villageVal = false;
        }
        break;

      case "Pincode":
        if (this.utilsService.validString) {
          this.pincodeVal = true;
        } else {
          this.pincodeVal = false;
        }
        break;

      case "Mobile":
        if (this.utilsService.validString) {
          this.mobileVal = true;
        } else {
          this.mobileVal = false;
        }
        break;

      case "Landline":
        if (this.utilsService.validString) {
          this.landlineVal = true;
        } else {
          this.landlineVal = false;
        }
        break;

      case "Plot":
        if (this.utilsService.validString) {
          this.plotVal = true;
        } else {
          this.plotVal = false;
        }
        break;

      case "Address 1":
        if (this.utilsService.validString) {
          this.address1Val = true;
        } else {
          this.address1Val = false;
        }
        break;

      case "Address 2":
        if (this.utilsService.validString) {
          this.address2Val = true;
        } else {
          this.address2Val = false;
        }
        break;

    }
    return data;
  }

  /**
  This function is called when user clicked outside the input fields
  @param value - input validation case
  @param field - field name
  */
  onBlurValidation(value, field) {
    if (value) {
      this.nameUnitValBlur = false;
      this.cityValBlur = false;
      this.blockValBlur = false;
      this.activityValBlur = false;
      this.panValBlur = false;
      this.districtValBlur = false;
      this.villageValBlur = false;
      this.pincodeValBlur = false;
      this.mobileValBlur = false;
      this.landlineValBlur = false;
      this.plotValBlur = false;
      this.address1ValBlur = false;
      this.address2ValBlur = false;
      this.onlyNumber = this.validationMsg.onlyNumVal;
      this.onlyAlphabet = "Please enter only alphabets";
      this.avoidSpecialChar = "Please enter alphabets & numbers";
      switch (field) {
        case "Mobile":
          if (!(value.match(/^\d+$/))) {
            this.unitDetails.mobileNum = '';
            this.mobileValBlur = true;
            this.setTimeOut();
          } else if (value.length < 10) {
            this.onlyNumber = this.validationMsg.mobVal;
            this.unitDetails.mobileNum = '';
            this.mobileValBlur = true;
            this.setTimeOut();
          }
          break;

        case "NameUnit":
          if  (!value.match(/^[a-zA-Z0-9&/.#,\s-]*$/)) {
            this.unitDetails.nameOfUnit = '';
            this.nameUnitValBlur = true;
            this.setTimeOut();
          }
          break;

        case "Activity":
          if (!(value.match(/^[a-zA-Z&/.#,\s-]*$/))) {
            this.unitDetails.activityOfUnit = '';
            this.activityValBlur = true;
            this.setTimeOut();
          }
          break;

        case "PAN":
          if (!(value.match(/[A-Z]{5}\d{4}[A-Z]{1}/))) {
            this.avoidSpecialChar = this.validationMsg.panVal;
            this.unitDetails.panTan = '';
            this.panValBlur = true;
            this.setTimeOut();
          } else if (value.length < 10) {
            this.avoidSpecialChar = this.validationMsg.panVal;
            this.unitDetails.panTan = '';
            this.panValBlur = true;
            this.setTimeOut();
          }
          break;

        case "City":
          if (!(value.match(/^[a-zA-Z&/.#,\s-]*$/))) {
            this.unitDetails.city = '';
            this.cityValBlur = true;
            this.setTimeOut();
          }
          break;

        case "District":
          if (!(value.match(/^[a-zA-Z&/.#,\s-]*$/))) {
            this.unitDetails.district = '';
            this.districtValBlur = true;
            this.setTimeOut();
          }
          break;

        case "Block":
          if  (!value.match(/^[a-zA-Z0-9&/.#,\s-]*$/)) {
            this.unitDetails.blockTehsilSubdistrict = '';
            this.blockValBlur = true;
            this.setTimeOut();
          }
          break;

        case "Village":
          if (!(value.match(/^[a-zA-Z&/.#,\s-]*$/))) {
            this.unitDetails.village = '';
            this.villageValBlur = true;
            this.setTimeOut();
          }
          break;

        case "Pincode":
          if (!(value.match(/^\d+$/))) {
            this.unitDetails.pinCode = '';
            this.pincodeValBlur = true;
            this.setTimeOut();
          } else if (value.length < 6) {
            this.onlyNumber = this.validationMsg.pinVal;
            this.unitDetails.pinCode = '';
            this.pincodeValBlur = true;
            this.setTimeOut();
          }
          break;

        case "Landline":
          if (!(value.match(/^\d+$/))) {
            this.unitDetails.landlineNum = '';
            this.landlineValBlur = true;
            this.setTimeOut();
          } else if (value.length < 8) {
            this.onlyNumber = this.validationMsg.landVal;
            this.unitDetails.landlineNum = '';
            this.landlineValBlur = true;
            this.setTimeOut();
          }
          break;

        case "Plot":
          if  (!value.match(/^[a-zA-Z0-9&/.#,\s-]*$/)) {
            this.unitDetails.plotBuildingFlatNum = '';
            this.plotValBlur = true;
            this.setTimeOut();
          }
          break;

        case "Address 1":
          if  (!value.match(/^[a-zA-Z0-9&/.#,\s-]*$/)) {
            this.unitDetails.addressLine1 = '';
            this.address1ValBlur = true;
            this.setTimeOut();
          }
          break;

        case "Address 2":
          if  (!value.match(/^[a-zA-Z0-9&/.#,\s-]*$/)) {
            this.unitDetails.addressLine2 = '';
            this.address2ValBlur = true;
            this.setTimeOut();
          }
          break;
      }
    }
  }
}