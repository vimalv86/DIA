import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { DIAConstants } from '../../../../Shared/constants';
import { Constants } from '../../../../Shared/Constants/constants.service';

import { EstablishmentDetails } from '../../../../Service/SME/Presanction/EstablishmentDetails/establishmentDetails';
import { AddEstablishmentDetailsService } from '../../../../Service/SME/Presanction/EstablishmentDetails/AddEstablishmentDetails/addEstablishmentDetails.service';
import { SmePresanctionGetEstablishmentListService } from '../../../../Service/SME/Presanction/EstablishmentDetails/GetEstablishmentDetails/getEstablishmentDetails.service';

import { NgxGalleryOptions, NgxGalleryImage, NgxGalleryAnimation } from 'ngx-gallery';
import { UtilsService } from '../../../../Shared/UtilsService/utils.service';
import { ValidationMessageService } from '../../../../Shared/ValidationMsgs/validationMsg.service';

@Component({
  selector: 'establishmentDetail',
  templateUrl: './establishmentDetail.component.html',
  styleUrls: ['./establishmentDetail.component.scss', '../../../module.component.scss'],
  providers: [
    AddEstablishmentDetailsService,
    SmePresanctionGetEstablishmentListService,
    UtilsService,
    Constants,
    ValidationMessageService
  ]
})

export class EstablishmentDetailComponent implements OnInit {
  private establishmentWebVO: any;
  private apiRequest: any;
  private establishmentList: any;
  private message: string;
  private statusMsg: string;
  private states: any[];
  private upToFive: any[];
  private ownership: any = [];
  private noData: boolean = false;
  private proposedActivity: any = [];
  private executivePFIndex: any;
  private indexVal: any;
  private checked: boolean;
  private registredAddressUnit: any = {};
  private unRegistredAddressUnit: any = {};
  private images: any = [];
  private pfId: string;
  // private loanNumber: string;
  private inspectionID: string;
  private galleryOptionsSelfy: NgxGalleryOptions[];
  private galleryImagesSelfy: NgxGalleryImage[];
  private galleryOptions: NgxGalleryOptions[];
  private galleryImages: NgxGalleryImage[];
  private isLoanEditable: boolean;
  private isPinCodeValid: boolean = true;
  private loanDetailsWithOutInspection: any;
  private cityVal: boolean = false;
  private districtVal: boolean = false;
  private blockVal: boolean = false;
  private villageVal: boolean = false;
  private pincodeVal: boolean = false;
  private activityVal: boolean = false;
  private detailsVal: boolean = false;
  private plotVal: boolean = false;
  private address1Val: boolean = false;
  private address2Val: boolean = false;
  private establishmentListDupl = null;
  private cityValBlur: boolean = false;
  private districtValBlur: boolean = false;
  private blockValBlur: boolean = false;
  private villageValBlur: boolean = false;
  private pincodeValBlur: boolean = false;
  private activityValBlur: boolean = false;
  private detailsValBlur: boolean = false;
  private plotValBlur: boolean = false;
  private address1ValBlur: boolean = false;
  private address2ValBlur: boolean = false;
  private onlyNumber: string;
  private onlyAlphabet: string;
  private avoidSpecialChar: string;
  private currentDate: any;
  private validationMsg: any;
  private dataResponse: any = {};

  constructor(private _addEstablishmentDetailsService: AddEstablishmentDetailsService, private service: SmePresanctionGetEstablishmentListService, private route: ActivatedRoute, private utilsService: UtilsService, private constants: Constants, private validationMessageService: ValidationMessageService) {
    this.states = DIAConstants.states;
    this.upToFive = DIAConstants.upToFive;
    this.ownership = DIAConstants.ownership
    this.proposedActivity = DIAConstants.proposedActivity;
    this.currentDate = new Date();
  }

  @Input() establishmentDetails: EstablishmentDetails;
  responseStatus: Object = [];
  status: boolean;
  /**
  This function is used for adding the establishment details
  */
  addEstablishmentDetail() {
    if (this.inspectionID) {
      //    if (this.establishmentList[this.indexVal].dateOfInspectionTSTemp && this.establishmentList[this.indexVal].building_no && this.establishmentList[this.indexVal].addressLine1 && this.establishmentList[this.indexVal].addressLine2 && this.establishmentList[this.indexVal].state && this.establishmentList[this.indexVal].city && this.establishmentList[this.indexVal].pinCode) {
      if (this.establishmentList[this.indexVal].pinCode) {
        let pinCode = (this.establishmentList[this.indexVal].pinCode).toString();
        if (this.establishmentList[this.indexVal].pinCode.length < 6) {
          this.isPinCodeValid = false;
        } else if (pinCode.charAt(0) == '0') {
          this.isPinCodeValid = false;
        } else {
          this.isPinCodeValid = true;
        }
      } else {
        this.isPinCodeValid = true;
      }

      if (this.isPinCodeValid) {
        if (this.establishmentList[this.indexVal].dateOfInspectionTSTemp) {
          let actualTime = this.establishmentList[this.indexVal].dateOfInspectionTSTemp;
          let timeStamp = new Date(actualTime).getTime().toString();
          this.establishmentList[this.indexVal].dateOfInspectionTS = timeStamp;
        } else {
          this.establishmentList[this.indexVal].dateOfInspectionTS = null;
        }

        delete this.establishmentList[this.indexVal].dateOfInspectionTSTemp;
        this.checked = this.establishmentList[this.indexVal].checked;
        delete this.establishmentList[this.indexVal].checked;
        delete this.establishmentList[this.indexVal].message;
        delete this.establishmentList[this.indexVal].imageListStatus;
        // delete this.establishmentList[this.indexVal].pinCodeStatus;
        if (this.establishmentList[this.indexVal].losNum) {
          delete this.establishmentList[this.indexVal].losNum;
        }
        if (this.inspectionID && !this.establishmentList[this.indexVal].inspectionId) {
          this.establishmentList[this.indexVal].inspectionId = this.inspectionID;
        }
        this.establishmentList[this.indexVal] = this.utilsService.dataSourceSave(this.establishmentList[this.indexVal]);

        var objectToPost: { establishmentWebVO: any; appId: string; executivePFIndex: string; } = { establishmentWebVO: this.establishmentList[this.indexVal], appId: "WEB-DIA", executivePFIndex: this.pfId };
        this._addEstablishmentDetailsService.postComment(objectToPost).subscribe(
          data => {
            this.dataResponse = data;
            if (this.dataResponse.responseMessage == "Successful") {
              this.establishmentList[this.indexVal].dateOfInspectionTSTemp = new Date(parseInt(this.establishmentList[this.indexVal].dateOfInspectionTS));
              this.establishmentList[this.indexVal].message = this.constants.getMessage('successMsg');
              this.establishmentList[this.indexVal].establishRefId = this.dataResponse.refId;
              this.statusMsg = "success";
            } else {
              this.establishmentList[this.indexVal].message = this.dataResponse.responseMessage;
              this.statusMsg = "error";
            }
            this.setTimeOut();
          },
          err => {
            this.establishmentList[this.indexVal].message = this.constants.getMessage('errorMsg');
            this.statusMsg = "error";
            this.setTimeOut();
          },
          () => console.log('Request Completed')
        );
        this.establishmentList[this.indexVal].checked = this.checked;
        this.status = true;
      } else {
        if (!this.isPinCodeValid) {
          this.establishmentList[this.indexVal].message = this.constants.getMessage('pinCodeVal');
          this.statusMsg = "error";
        }
        this.setTimeOut();
      }
      // } else {
      //     this.establishmentList[this.indexVal].message = this.constants.getMessage('requiredFieldVal');
      //     this.statusMsg = "error";
      //     this.setTimeOut();
      // }
    } else {
      this.establishmentList[this.indexVal].message = this.constants.getMessage('unitDetailVal');
      this.statusMsg = "error";
      this.setTimeOut();
    }
  }

  /**
  This function is used for setting the timeout
  */
  setTimeOut() {
    setTimeout(() => {
      this.establishmentList[this.indexVal].message = "";
      this.onlyNumber = "";
      this.onlyAlphabet = "";
      this.avoidSpecialChar = "";
    }, 3000);
  }

  /**
  This function is called when component loads
  */
  ngOnInit() {
    this.establishmentDetails = new EstablishmentDetails();
    window.scrollTo(0, 0);
    if (localStorage.getItem("isLoanEditable") != null && localStorage.getItem("isLoanEditable") != "null") {
      if (localStorage.getItem("isLoanEditable") == "true") {
        this.isLoanEditable = true;
      } else {
        this.isLoanEditable = false;
      }
    }
    if (localStorage.getItem("userDetails") != "null" && localStorage.getItem("userDetails") != null && localStorage.getItem("inspectionID") != "null" && localStorage.getItem("inspectionID") != null) {
      // this.loanNumber = JSON.parse(localStorage.getItem('loanNo'));
      this.inspectionID = JSON.parse(localStorage.getItem("inspectionID"));
      this.executivePFIndex = JSON.parse(localStorage.getItem("userDetails"));
      this.pfId = this.executivePFIndex.user.pfId.toString();
      this.getEstablishmentDetails();
    } else {
      this.getDataFromLocalStorage();
    }
    this.getValidationMessage();
  }

  /**
  This function is used for getting the validation messages
  */
  getValidationMessage() {
    this.validationMessageService.getValidationMessage().subscribe(response => {
      if (response) {
        this.validationMsg = response;
      } else {
        console.log("Something worng");
      }
    })
  }

  /**
  This function is used for getting the establishment details
  @return Nothing
  */
  getEstablishmentDetails() {
    this.apiRequest = { "appId": "WEB-DIA", "executivePFIndex": this.pfId, "key": this.inspectionID };
    this.service.getEstablishmentList(this.apiRequest).subscribe(response => {
      if (response.establishmentWebVOList) {
        this.registredAddressUnit = JSON.parse(localStorage.getItem("registredAddressUnit"));
        this.establishmentList = response.establishmentWebVOList;
        if (this.establishmentList.length > 0) {
          for (let k = 0; k < this.establishmentList.length; k++) {
            if (this.establishmentList[k].establishRefId == null) {
              this.loanDetailsWithOutInspection = JSON.parse(localStorage.getItem("loanDetailsWithOutInspection"));
              if (this.loanDetailsWithOutInspection) {
                if (this.loanDetailsWithOutInspection.establishmentList && this.loanDetailsWithOutInspection.establishmentList.length > 0) {
                  if (this.loanDetailsWithOutInspection.establishmentList.length > k) {
                    this.establishmentList[k] = this.loanDetailsWithOutInspection.gurantorList[k];
                    this.establishmentList[k].establishRefId = null;
                    this.establishmentList[k] = this.setEstablishmentObject(this.establishmentList[k]);
                    this.establishmentList[k] = this.utilsService.dataSourceCheckFromLOS(this.establishmentList[k]);
                  } else {
                    this.establishmentList[k] = this.utilsService.dataSourceCheck(this.establishmentList[k]);
                  }
                }
              } else {
                this.establishmentList[k] = this.utilsService.dataSourceCheck(this.establishmentList[k]);
              }
            } else {
              this.establishmentList[k] = this.utilsService.dataSourceCheck(this.establishmentList[k]);
            }
          }
          this.unRegistredAddressUnit = JSON.stringify(this.establishmentList[0]);
          this.imageGalleryOptions();
          for (let i = 0; i < this.establishmentList.length; i++) {
            this.establishmentList[i].checked = false;
            this.establishmentList[i].message = '';
            if (this.establishmentList[i].dateOfInspectionTS != null) {
              if (+this.establishmentList[i].dateOfInspectionTS == 0) {
                this.establishmentList[i].dateOfInspectionTSTemp = '';
              } else {
                this.establishmentList[i].dateOfInspectionTSTemp = new Date(this.establishmentList[i].dateOfInspectionTS);
              }
            }
          }
          this.establishmentListDupl = this.establishmentList;
        } else {
          this.getDataFromLocalStorage();
        }
      } else {
        this.getDataFromLocalStorage();
      }
    })
  }

  /**
 This function is used for getting the establishment details from local storage
 @return Nothing
 */
  getDataFromLocalStorage() {
    this.loanDetailsWithOutInspection = JSON.parse(localStorage.getItem("loanDetailsWithOutInspection"));
    if (this.loanDetailsWithOutInspection) {
      if (this.loanDetailsWithOutInspection.establishmentList && this.loanDetailsWithOutInspection.establishmentList.length > 0) {
        this.establishmentList = this.loanDetailsWithOutInspection.establishmentList;
        for (let k = 0; k < this.establishmentList.length; k++) {
          this.establishmentList[k] = this.setEstablishmentObject(this.establishmentList[k]);
        }
        this.establishmentList = this.utilsService.dataSourceCheckFromLOSArray(this.establishmentList);
        this.establishmentListDupl = this.establishmentList;
        this.unRegistredAddressUnit = JSON.stringify(this.establishmentList[0]);
        this.imageGalleryOptions();
        for (let i = 0; i < this.establishmentList.length; i++) {
          this.establishmentList[i].checked = false;
          this.establishmentList[i].message = '';
          this.establishmentList[i].establishRefId = null;
          this.setStateFromLOS(this.establishmentList[i].state, i);
          if (this.establishmentList[i].dateOfInspectionTS != null) {
            if (+this.establishmentList[i].dateOfInspectionTS == 0) {
              this.establishmentList[i].dateOfInspectionTSTemp = '';
            } else {
              this.establishmentList[i].dateOfInspectionTSTemp = new Date(this.establishmentList[i].dateOfInspectionTS);
            }
          }
        }
      } else {
        this.noData = true;
      }
    } else {
      this.noData = true;
    }
  }

  /**
 This function is used for setting the establishment object
 @params: object - establishment object
 @return Nothing
 */
  setEstablishmentObject(object) {
    object["addressLine2"] = null;
    object["building_no"] = null;
    object["district"] = null;
    object["sub_district"] = null;
    object["village"] = null;
    object["ownership"] = null;
    object["proposedActivity"] = null;
    object["activity"] = null;
    object["comment"] = null;
    return object;
  }

  /**
 This function is called when user clicked on the tab of the stablishment
 @params: i- index 
 @params: establishmentDetail - Object
 @return Nothing
 */
  tabHeaderClick(i, establishmentDetail) {
    this.indexVal = i;
    this.galleryImagesSelfy = [];
    this.galleryImages = [];
    if (establishmentDetail.imageList != null) {
      for (let j = 0; j < establishmentDetail.imageList.length; j++) {
        let latitudeAndLongitude = "Latitude: " + establishmentDetail.imageList[j].imageLatitude + ", " + "Longitude: " + establishmentDetail.imageList[j].imageLongitude;
        let imageObj = {
          small: establishmentDetail.imageList[j].imagePath,
          medium: establishmentDetail.imageList[j].imagePath,
          big: establishmentDetail.imageList[j].imagePath,
          description: latitudeAndLongitude
        }
        if (establishmentDetail.imageList[j].imageType == "SELFIE_TYPE") {
          if (this.galleryImagesSelfy.length < 1) {
            this.galleryImagesSelfy.push(imageObj);
          }
        } else {
          this.galleryImages.push(imageObj);
        }
      }
    }
    for (var k = 0; k < this.establishmentList.length; k++) {
      this.establishmentList[k].message = '';
    }
  }

  /**
 This function is used for setting the image upload from mobile
 @return Nothing
 */
  imageGalleryOptions() {
    this.galleryOptionsSelfy = [
      {
        "image": false,
        "height": "80px",
        "width": "100px",
        "thumbnailsColumns": 1
      }
    ];

    this.galleryOptions = [
      {
        "image": false,
        "height": "80px",
        "width": "100%",
        "thumbnailsColumns": 6,
        "previewDescription": true
      }
    ];
  }

  /**
  This function is used for setting the registered address from local storage
  @params: i - index
  @return Nothing
  */
  sameAddress(i) {
    if (this.establishmentList[this.indexVal].checked) {
      this.unRegistredAddressUnit = JSON.stringify(this.establishmentList[this.indexVal]);
      if (!(this.establishmentListDupl[this.indexVal].building_noStatus == 'LOS' || this.establishmentListDupl[this.indexVal].building_noStatus == 'Mob')) {
        this.establishmentList[this.indexVal].building_no = this.registredAddressUnit.plotBuildingFlatNum;
      }
      if (!(this.establishmentListDupl[this.indexVal].addressLine1Status == 'LOS' || this.establishmentListDupl[this.indexVal].addressLine1Status == 'Mob')) {
        this.establishmentList[this.indexVal].addressLine1 = this.registredAddressUnit.addressLine1;
      }
      if (!(this.establishmentListDupl[this.indexVal].addressLine2Status == 'LOS' || this.establishmentListDupl[this.indexVal].addressLine2Status == 'Mob')) {
        this.establishmentList[this.indexVal].addressLine2 = this.registredAddressUnit.addressLine2;
      }
      if (!(this.establishmentListDupl[this.indexVal].stateStatus == 'LOS' || this.establishmentListDupl[this.indexVal].stateStatus == 'Mob')) {
        this.establishmentList[this.indexVal].state = this.registredAddressUnit.state;
      }
      if (!(this.establishmentListDupl[this.indexVal].cityStatus == 'LOS' || this.establishmentListDupl[this.indexVal].cityStatus == 'Mob')) {
        this.establishmentList[this.indexVal].city = this.registredAddressUnit.city;
      }
      if (!(this.establishmentListDupl[this.indexVal].districtStatus == 'LOS' || this.establishmentListDupl[this.indexVal].districtStatus == 'Mob')) {
        this.establishmentList[this.indexVal].district = this.registredAddressUnit.district;
      }
      if (!(this.establishmentListDupl[this.indexVal].sub_districtStatus == 'LOS' || this.establishmentListDupl[this.indexVal].sub_districtStatus == 'Mob')) {
        this.establishmentList[this.indexVal].sub_district = this.registredAddressUnit.blockTehsilSubdistrict;
      }
      if (!(this.establishmentListDupl[this.indexVal].villageStatus == 'LOS' || this.establishmentListDupl[this.indexVal].villageStatus == 'Mob')) {
        this.establishmentList[this.indexVal].village = this.registredAddressUnit.village;
      }
      if (!(this.establishmentListDupl[this.indexVal].pinCodeStatus == 'LOS' || this.establishmentListDupl[this.indexVal].pinCodeStatus == 'Mob')) {
        this.establishmentList[this.indexVal].pinCode = this.registredAddressUnit.pinCode;
      }
    } else {
      this.unRegistredAddressUnit = JSON.parse(this.unRegistredAddressUnit);
      this.establishmentList[this.indexVal].building_no = this.unRegistredAddressUnit.building_no;
      this.establishmentList[this.indexVal].addressLine1 = this.unRegistredAddressUnit.addressLine1;
      this.establishmentList[this.indexVal].addressLine2 = this.unRegistredAddressUnit.addressLine2;
      this.establishmentList[this.indexVal].state = this.unRegistredAddressUnit.state;
      this.establishmentList[this.indexVal].city = this.unRegistredAddressUnit.city;
      this.establishmentList[this.indexVal].district = this.unRegistredAddressUnit.district;
      this.establishmentList[this.indexVal].sub_district = this.unRegistredAddressUnit.sub_district;
      this.establishmentList[this.indexVal].village = this.unRegistredAddressUnit.village;
      this.establishmentList[this.indexVal].pinCode = this.unRegistredAddressUnit.pinCode;
    }
  }

  /**
    This function is called when user clicked on the input fields
    @param data - input validation case
    @param field - field name
    @return data - input validation case
    */
  keypressCheck(data, field) {
    this.cityVal = false;
    this.districtVal = false;
    this.blockVal = false;
    this.villageVal = false;
    this.pincodeVal = false;
    this.activityVal = false;
    this.detailsVal = false;
    this.plotVal = false;
    this.address1Val = false;
    this.address2Val = false;
    switch (field) {
      case "City":
        if (this.utilsService.validString) {
          this.cityVal = true;
        } else {
          this.cityVal = false;
        }
        break;

      case "District":
        if (this.utilsService.validString) {
          this.districtVal = true;
        } else {
          this.districtVal = false;
        }
        break;

      case "Block":
        if (this.utilsService.validString) {
          this.blockVal = true;
        } else {
          this.blockVal = false;
        }
        break;

      case "Village":
        if (this.utilsService.validString) {
          this.villageVal = true;
        } else {
          this.villageVal = false;
        }
        break;

      case "Pincode":
        if (this.utilsService.validString) {
          this.pincodeVal = true;
        } else {
          this.pincodeVal = false;
        }
        break;

      case "Activity":
        if (this.utilsService.validString) {
          this.activityVal = true;
        } else {
          this.activityVal = false;
        }
        break;

      case "Details":
        if (this.utilsService.validString) {
          this.detailsVal = true;
        } else {
          this.detailsVal = false;
        }
        break;

      case "Plot":
        if (this.utilsService.validString) {
          this.plotVal = true;
        } else {
          this.plotVal = false;
        }
        break;

      case "Address 1":
        if (this.utilsService.validString) {
          this.address1Val = true;
        } else {
          this.address1Val = false;
        }
        break;

      case "Address 2":
        if (this.utilsService.validString) {
          this.address2Val = true;
        } else {
          this.address2Val = false;
        }
        break;
    }
    return data;
  }

  /**
  This function is called when user clicked outside the input fields
  @param value - input validation case
  @param field - field name
  @return Nothing
  */
  onBlurValidation(value, field) {
    if (value) {
      this.cityValBlur = false;
      this.districtValBlur = false;
      this.blockValBlur = false;
      this.villageValBlur = false;
      this.pincodeValBlur = false;
      this.activityValBlur = false;
      this.detailsValBlur = false;
      this.plotValBlur = false;
      this.address1ValBlur = false;
      this.address2ValBlur = false;
      this.onlyNumber = this.validationMsg.onlyNumVal;
      this.onlyAlphabet = "Please enter only alphabets";
      this.avoidSpecialChar = "Please enter alphabets & numbers";
      switch (field) {
        case "City":
          if (!(value.match(/^[a-zA-Z&-/.#, ]*$/))) {
            this.establishmentList[this.indexVal].city = '';
            this.cityValBlur = true;
            this.setTimeOut();
          }
          break;

        case "District":
          if (!(value.match(/^[a-zA-Z&/.#,\s-]*$/))) {
            this.establishmentList[this.indexVal].district = '';
            this.districtValBlur = true;
            this.setTimeOut();
          }
          break;

        case "Block":
          if (!value.match(/^[a-zA-Z0-9&/.#,\s-]*$/)) {
            this.establishmentList[this.indexVal].sub_district = '';
            this.blockValBlur = true;
            this.setTimeOut();
          }
          break;

        case "Village":
          if (!(value.match(/^[a-zA-Z&/.#,\s-]*$/))) {
            this.establishmentList[this.indexVal].village = '';
            this.villageValBlur = true;
            this.setTimeOut();
          }
          break;

        case "Pincode":
          if (!(value.match(/^\d+$/))) {
            this.establishmentList[this.indexVal].pinCode = '';
            this.pincodeValBlur = true;
            this.setTimeOut();
          } else if (value.length < 6) {
            this.onlyNumber = this.validationMsg.pinVal;
            this.establishmentList[this.indexVal].pinCode = '';
            this.pincodeValBlur = true;
            this.setTimeOut();
          }
          break;

        case "Activity":
          if (!(value.match(/^[a-zA-Z&/.#,\s-]*$/))) {
            this.establishmentList[this.indexVal].activity = '';
            this.activityValBlur = true;
            this.setTimeOut();
          }
          break;

        case "Details":
          if (!(value.match(/^[a-zA-Z&/.#,\s-]*$/))) {
            this.establishmentList[this.indexVal].comment = '';
            this.detailsValBlur = true;
            this.setTimeOut();
          }
          break;

        case "Plot":
          if (!value.match(/^[a-zA-Z0-9&/.#,\s-]*$/)) {
            this.establishmentList[this.indexVal].building_no = '';
            this.plotValBlur = true;
            this.setTimeOut();
          }
          break;

        case "Address 1":
          if (!value.match(/^[a-zA-Z0-9&/.#,\s-]*$/)) {
            this.establishmentList[this.indexVal].addressLine1 = '';
            this.address1ValBlur = true;
            this.setTimeOut();
          }
          break;

        case "Address 2":
          if (!value.match(/^[a-zA-Z0-9&/.#,\s-]*$/)) {
            this.establishmentList[this.indexVal].addressLine2 = '';
            this.address2ValBlur = true;
            this.setTimeOut();
          }
          break;

      }
    }
  }

  /**
  This function is used for setting the state from LOS
  @param stateName - state name from los
  @param currentObj - current index
  @return Nothing
  */
  setStateFromLOS(stateName, currentObj) {
    switch (stateName) {
      case "06-HARYANA":
        this.establishmentList[currentObj].state = "HARYANA"
        break;

      case "27-MAHARASHTRA":
        this.establishmentList[currentObj].state = "MAHARASHTRA"
        break;

      case "08-RAJASTHAN":
        this.establishmentList[currentObj].state = "RAJASTHAN"
        break;

      case "84-NCT OF DELHI":
        this.establishmentList[currentObj].state = "NCT OF DELHI"
        break;

      case "09-UTTAR PRADESH":
        this.establishmentList[currentObj].state = "UTTAR PRADESH"
        break;

      case "10-BIHAR":
        this.establishmentList[currentObj].state = "BIHAR"
        break;

      case "12-ARUNACHAL PRADESH":
        this.establishmentList[currentObj].state = "ARUNACHAL PRADESH"
        break;

      case "11-SIKKIM":
        this.establishmentList[currentObj].state = "SIKKIM"
        break;

      case "13-NAGALAND":
        this.establishmentList[currentObj].state = "NAGALAND"
        break;

      case "17-MEGHALAYA":
        this.establishmentList[currentObj].state = "MEGHALAYA"
        break;

      case "15-MIZORAM":
        this.establishmentList[currentObj].state = "MIZORAM"
        break;

      case "16-TRIPURA":
        this.establishmentList[currentObj].state = "TRIPURA"
        break;

      case "14-MANIPUR":
        this.establishmentList[currentObj].state = "MANIPUR"
        break;

      case "07-DELHI":
        this.establishmentList[currentObj].state = "DELHI"
        break;

      case "18-ASSAM":
        this.establishmentList[currentObj].state = "ASSAM"
        break;

      case "19-WEST BENGAL":
        this.establishmentList[currentObj].state = "WEST BENGAL"
        break;

      case "20-JHARKHAND":
        this.establishmentList[currentObj].state = "JHARKHAND"
        break;

      case "21-ODISHA":
        this.establishmentList[currentObj].state = "ODISHA"
        break;

      case "22-CHHATTISGARH":
        this.establishmentList[currentObj].state = "CHHATTISGARH"
        break;

      case "23-MADHYA PRADESH":
        this.establishmentList[currentObj].state = "MADHYA PRADESH"
        break;

      case "24-GUJARAT":
        this.establishmentList[currentObj].state = "GUJARAT"
        break;

      case "25-DAMAN AND DIU":
        this.establishmentList[currentObj].state = "DAMAN AND DIU"
        break;

      case "26-DADRA  AND NAGAR HAVELI":
        this.establishmentList[currentObj].state = "DADRA  AND NAGAR HAVELI"
        break;

      case "27-MAHARASHTRA":
        this.establishmentList[currentObj].state = "MAHARASHTRA"
        break;

      case "28-ANDHRA PRADESH":
        this.establishmentList[currentObj].state = "ANDHRA PRADESH"
        break;

      case "29-KARNATAKA":
        this.establishmentList[currentObj].state = "KARNATAKA"
        break;

      case "31-LAKSHADWEEP":
        this.establishmentList[currentObj].state = "LAKSHADWEEP"
        break;

      case "32-KERALA":
        this.establishmentList[currentObj].state = "KERALA"
        break;

      case "33-TAMIL NADU":
        this.establishmentList[currentObj].state = "TAMIL NADU"
        break;

      case "30-GOA":
        this.establishmentList[currentObj].state = "GOA"
        break;

      case "34-PUDUCHERRY":
        this.establishmentList[currentObj].state = "PUDUCHERRY"
        break;

      case "35-ANDAMAN  AND NICOBAR ISLANDS":
        this.establishmentList[currentObj].state = "ANDAMAN  AND NICOBAR ISLANDS"
        break;

      case "02-HIMACHAL PRADESH":
        this.establishmentList[currentObj].state = "HIMACHAL PRADESH"
        break;

      case "01-JAMMU  AND KASHMIR":
        this.establishmentList[currentObj].state = "JAMMU  AND KASHMIR"
        break;

      case "03-PUNJAB":
        this.establishmentList[currentObj].state = "PUNJAB"
        break;

      case "04-CHANDIGARH":
        this.establishmentList[currentObj].state = "CHANDIGARH"
        break;

      case "05-UTTARAKHAND":
        this.establishmentList[currentObj].state = "UTTARAKHAND"
        break;
    }
  }
}