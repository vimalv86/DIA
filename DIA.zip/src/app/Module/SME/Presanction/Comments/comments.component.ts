import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';

import { DIAConstants } from '../../../../Shared/constants';
import { Constants } from '../../../../Shared/Constants/constants.service';

import { Comments } from '../../../../Service/SME/Presanction/Comments/comments';
import { AddCommentsService } from '../../../../Service/SME/Presanction/Comments/AddComments/addComments.service';
import { SmePresanctionGetCommentsService } from '../../../../Service/SME/Presanction/Comments/GetComments/getComments.service';
import { CheckSubmissionService } from '../../../../Service/SME/Presanction/Comments/checkSubmission/checkSubmission.service';
import { SubmitSMEPresanctionService } from '../../../../Service/SME/Presanction/Comments/submitSMEPresanction/submitSMEPresanction.service';
import { SmePresanctionGetReviewersService } from '../../../../Service/SME/Presanction/Comments/GetReviewers/getReviewers.service';
import { UtilsService } from '../../../../Shared/UtilsService/utils.service';

import { ConfirmationService } from 'primeng/primeng';
import { ValidationMessageService } from '../../../../Shared/ValidationMsgs/validationMsg.service';

@Component({
    selector: 'comments',
    templateUrl: './comments.component.html',
    styleUrls: ['./comments.component.scss', '../../../module.component.scss'],
    providers: [
        Comments,
        AddCommentsService,
        SmePresanctionGetCommentsService,
        CheckSubmissionService,
        SubmitSMEPresanctionService,
        SmePresanctionGetReviewersService,
        ConfirmationService,
        UtilsService,
        Constants,
        ValidationMessageService
    ]
})

export class CommentsComponent implements OnInit {
    private apiRequest: any;
    private responseStatus: Object = [];
    private comments: any;
    private borrowerRefId: string;
    private inspectionID: string;
    private status: boolean;
    private message: string;
    private statusMsg: string;
    private executivePFIndex: any;
    private applicationSource: any[];
    private pfIdOfReviewer: any = [];
    private noData: boolean;
    private pfId: string;
    private isSubmitValidationComplete: boolean;
    private isDisabled: boolean;
    private isValidationComplete: boolean;
    private isLoanEditable: boolean;
    private submissionStatusMessage: string;
    private reviewerList: any = [];
    private loanDetailsWithOutInspection: any;
    private otherVal: boolean = false;
    private positionVal: boolean = false;
    private nameVal: boolean = false;
    private dataVal: boolean = false;
    private remarkableVal: boolean = false;
    private commentsOnActVal: boolean = false;
    private commentsOnGenVal: boolean = false;
    private otherValBlur: boolean = false;
    private dataValBlur: boolean = false;
    private remarkableValBlur: boolean = false;
    private commentsOnActValBlur: boolean = false;
    private commentsOnGenValBlur: boolean = false;
    private positionValBlur: boolean = false;
    private nameValBlur: boolean = false;
    private onlyNumber: string;
    private onlyAlphabet: string;
    private avoidSpecialChar: string;
    private rejectCount: any;
    private validationMsg: any;
    private dataResponse: any = {};
    private checkSubmissionResponse: any = {};
    private submitDataResponse: any = {};

    constructor(private _addCommentsService: AddCommentsService, private service: SmePresanctionGetCommentsService, private checkSubmissionService: CheckSubmissionService, private submitSMEPresanctionService: SubmitSMEPresanctionService, private router: Router, private constants: Constants, private getReviewerService: SmePresanctionGetReviewersService, private utilsService: UtilsService, private confirmationService: ConfirmationService, private validationMessageService: ValidationMessageService) {
        this.applicationSource = DIAConstants.applicationSource;
    }

    /**
    This function is used for adding the comments
    @return Nothing
    */
    addComments() {
        //document.getElementById('test').scrollIntoView();
        var element = document.getElementById("bg-image");

        element.scrollLeft += 150;

        if (this.inspectionID) {
            this.isValidationComplete = true;
            //this.comments["borrowerRefId"] = this.borrowerRefId;
            //  if (this.comments.applicationSource && this.comments.commentsOnActivity && this.comments.commentOnGeneralWorkFirm && this.comments.commentsOnDataCollection && this.comments.pfIdOfReviewer) {
            if (this.comments.applicationSource == "Others") {
                if (!this.comments.otherSource) {
                    this.isValidationComplete = false;
                }
            }

            if (this.isValidationComplete) {
                this.comments["inspectionId"] = this.inspectionID;
                this.comments = this.utilsService.dataSourceSave(this.comments);
                var objectToPost: { officialComments: object; appId: string; executivePFIndex: string; } = { officialComments: this.comments, appId: "WEB-DIA", executivePFIndex: this.pfId };

                this._addCommentsService.postComment(objectToPost).subscribe(
                    data => {
                        this.dataResponse = data;
                        if (this.dataResponse.responseMessage == "Successful") {
                            this.checkSubmissionStatus();
                            this.getComments();
                            this.message = this.constants.getMessage('successMsg');
                            this.statusMsg = "success";
                        } else {
                            this.message = this.dataResponse.responseMessage;
                            this.statusMsg = "error";
                        }
                    },
                    err => {
                        this.message = this.constants.getMessage('errorMsg');
                        this.statusMsg = "error";
                    },
                    () => console.log('Request Completed')
                );
                this.status = true;
                this.setTimeOut();
            } else {
                this.message = this.constants.getMessage('requiredFieldVal');
                this.statusMsg = "error";
                this.setTimeOut();
            }
            // } else {
            //     this.message = this.constants.getMessage('requiredFieldVal');
            //     this.statusMsg = "error";
            //     this.setTimeOut();
            // }
        } else {
            this.message = this.constants.getMessage('unitDetailVal');
            this.statusMsg = "error";
            this.setTimeOut();
        }
    }

    /**
    This function is used for setting the timeout
    @return Nothing
    */
    setTimeOut() {
        setTimeout(() => {
            this.message = "";
            this.onlyNumber = "";
            this.onlyAlphabet = "";
            this.avoidSpecialChar = "";
        }, 3000);
    }

    /**
    This function is used for getting the reviewer list
    @return Nothing
    */
    getReviewerList() {
        var objectToPost: { inspectorPfId: any; } = { inspectorPfId: this.pfId };
        this.getReviewerService.getReviewerList(objectToPost).subscribe(
            data => {
                if (data.responseCode == 200) {
                    this.reviewerList = data.reviwerList;
                    for (let k = 0; k < this.reviewerList.length; k++) {
                        let pfObj = {
                            label: this.reviewerList[k].reviewerPfId, value: this.reviewerList[k].reviewerPfId
                        }
                        this.pfIdOfReviewer.push(pfObj);
                    }
                } else {
                    this.message = data.responseMessage;
                    this.statusMsg = "error";
                }
                this.getComments();
                this.setTimeOut();
            },
            err => {
                this.message = this.constants.getMessage('errorMsg');
                this.setTimeOut();
            },
            () => console.log('Request Completed')
        );
    }

    /**
    This function is used for checking the submission status of the inspection
    @return Nothing
    */
    checkSubmissionStatus() {
        var objectToPost: { appId: string; executivePFIndex: string; key: string; } = { appId: "WEB-DIA", executivePFIndex: this.pfId, key: this.inspectionID };

        this.checkSubmissionService.postComment(objectToPost).subscribe(
            data => {
                this.checkSubmissionResponse = data;
                if (this.checkSubmissionResponse.responseCode == 200) {
                    this.isSubmitValidationComplete = true;
                } else {
                    this.submissionStatusMessage = this.checkSubmissionResponse.responseMessage;
                    this.isSubmitValidationComplete = false;
                }
            },
            err => {
                this.isSubmitValidationComplete = false;
            },
            () => console.log('Request Completed')
        );
        this.status = true;
        this.setTimeOut();
    }

    /**
    This function is used for submitting the presanction
    @return Nothing
    */
    submitSMEPresanction() {
        this.rejectCount = +(localStorage.getItem("rejectedCount"));
        if (this.inspectionID) {
            if (this.rejectCount == 5) {
                this.message = this.constants.getMessage('rejectVal');
                this.statusMsg = "error";
                this.setTimeOut();
            } else {
                if (this.isSubmitValidationComplete) {
                    if (this.inspectionID) {
                        var objectToPost: { appId: string; executivePFIndex: string; key: string; } = { appId: "WEB-DIA", executivePFIndex: this.pfId, key: this.inspectionID };
                        this.submitSMEPresanctionService.postComment(objectToPost).subscribe(
                            data => {
                                this.submitDataResponse = data;
                                if (this.submitDataResponse.responseCode == 200) {
                                    this.message = this.constants.getMessage('submitSuccess');
                                    this.statusMsg = "success";
                                    this.router.navigate(['sme']);
                                } else {
                                    this.message = this.submitDataResponse.responseMessage;
                                    this.statusMsg = "error";
                                }
                            },
                            err => {
                                this.message = this.constants.getMessage('errorMsg');
                                this.statusMsg = "error";
                            },
                            () => console.log('Request Completed')
                        );
                        this.status = true;
                        this.setTimeOut();
                    } else {
                        this.message = this.constants.getMessage('unitDetailVal');
                        this.statusMsg = "error";
                        this.setTimeOut();
                    }
                } else {
                    if (this.submissionStatusMessage == "Please fill Establishment Details, Collateral Details" || this.submissionStatusMessage == "Please fill Establishment Details" || this.submissionStatusMessage == "Please fill Collateral Details") {
                        this.submissionStatusMessage = "You have submitted your Inspection from Web. To add images please open the Inspection in Mobile"
                    }
                    this.confirmationService.confirm({
                        //message: this.submissionStatusMessage,
                        message: this.submissionStatusMessage,
                        accept: () => {

                        }
                    });
                }
            }
        } else {
            this.message = this.constants.getMessage('unitDetailVal');
            this.statusMsg = "error";
            this.setTimeOut();
        }
    }

    /**
    This function is used for getting the comment details
    @return Nothing
    */
    getComments() {
        this.apiRequest = { "appId": "WEB-DIA", "executivePFIndex": this.pfId, "key": this.inspectionID };
        this.service.getComments(this.apiRequest).subscribe(response => {
            if (response.officialCommentsVO) {
                //this.registredAddressUnit = JSON.parse(localStorage.getItem("registredAddressUnit"));
                this.comments = response.officialCommentsVO;
                if (this.comments) {
                    if (this.comments.field_statusMap == null) {
                        this.comments = this.setFieldStatusObj();
                    }
                    this.comments = this.utilsService.dataSourceCheck(this.comments);
                    if (this.comments.applicationSource == "Others") {
                        this.isDisabled = true;
                    } else {
                        this.isDisabled = false;
                        this.comments.otherSource = null;
                    }
                }
            } else {
                this.getDataFromLocalStorage();
            }
            this.checkSubmissionStatus();
        })
    }

    /**
    This function is used for getting the data from local storage
    @return Nothing
    */
    getDataFromLocalStorage() {
        this.loanDetailsWithOutInspection = JSON.parse(localStorage.getItem("loanDetailsWithOutInspection"));
        if (this.loanDetailsWithOutInspection) {
            if (this.loanDetailsWithOutInspection.officialComments) {
                this.comments = this.loanDetailsWithOutInspection.officialComments;
                this.comments = this.utilsService.dataSourceCheckFromLOS(this.comments);
            } else {
                this.comments = this.utilsService.dataSourceCheckFromLOS(this.comments);
                this.noData = true;
            }
        } else {
            this.comments = this.utilsService.dataSourceCheckFromLOS(this.comments);
            this.noData = true;
        }
    }

    /**
    This function is used for setting the field status
    @return Nothing
    */
    setFieldStatusObj() {
        var obj = this.comments;
        Object.keys(obj).forEach(function (key) {
            if (key.substr(-6) == "Status") {
                obj[key] = "null"
            }
        });
        return obj;
    }

    /**
   This function called when componet loads
   @return Nothing
   */
    ngOnInit() {
        this.comments = new Comments();
        if (localStorage.getItem("isLoanEditable") != null && localStorage.getItem("isLoanEditable") != "null") {
            if (localStorage.getItem("isLoanEditable") == "true") {
                this.isLoanEditable = true;
            } else {
                this.isLoanEditable = false;
            }
        }
        if (localStorage.getItem("userDetails") != "null" && localStorage.getItem("userDetails") != null && localStorage.getItem("borrowerRefID") != "null" && localStorage.getItem("borrowerRefID") != null && localStorage.getItem("inspectionID") != "null" && localStorage.getItem("inspectionID") != null) {
            this.executivePFIndex = JSON.parse(localStorage.getItem("userDetails"));
            this.pfId = this.executivePFIndex.user.pfId.toString();
            this.borrowerRefId = JSON.parse(localStorage.getItem('borrowerRefID'));
            if (localStorage.getItem("inspectionID") != "null" && localStorage.getItem("inspectionID") != null) {
                this.inspectionID = JSON.parse(localStorage.getItem("inspectionID"));
            }
            this.getReviewerList();

        } else {
            this.getDataFromLocalStorage();
        }
        this.getValidationMessage();
    }

    /**
   This function is used for getting the validation message
   @return Nothing
   */
    getValidationMessage() {
        this.validationMessageService.getValidationMessage().subscribe(response => {
            if (response) {
                this.validationMsg = response;
            } else {
                console.log("Something worng");
            }
        })
    }

    /**
   This function is used when selecting the application source dropdown
   @return Nothing
   */
    applicationSourceSelection(data) {
        if (data == "Others") {
            this.isDisabled = true;
        } else {
            this.isDisabled = false;
            this.comments.otherSource = null;
        }
    }

    /**
    This function is called when user clicked on the input fields
    @param data - input validation case
    @param field - field name
    @return data - input validation case
    */
    keypressCheck(data, field) {
        this.otherVal = false;
        this.positionVal = false;
        this.nameVal = false;
        this.commentsOnActVal = false;
        this.commentsOnGenVal = false;
        this.dataVal = false;
        this.remarkableVal = false;
        switch (field) {
            case "Others":
                if (this.utilsService.validString) {
                    this.otherVal = true;
                } else {
                    this.otherVal = false;
                }
                break;

            case "CommentsOnActivity":
                if (this.utilsService.validString) {
                    this.commentsOnActVal = true;
                } else {
                    this.commentsOnActVal = false;
                }
                break;

            case "CommentsOnGeneral":
                if (this.utilsService.validString) {
                    this.commentsOnGenVal = true;
                } else {
                    this.commentsOnGenVal = false;
                }
                break;

            case "Position":
                if (this.utilsService.validString) {
                    this.positionVal = true;
                } else {
                    this.positionVal = false;
                }
                break;

            case "DataCollection":
                if (this.utilsService.validString) {
                    this.dataVal = true;
                } else {
                    this.dataVal = false;
                }
                break;

            case "remarkablePoint":
                if (this.utilsService.validString) {
                    this.remarkableVal = true;
                } else {
                    this.remarkableVal = false;
                }
                break;

            case "Name":
                if (this.utilsService.validString) {
                    this.nameVal = true;
                } else {
                    this.nameVal = false;
                }
                break;

        }
        return data;
    }

    /**
    This function is called when user clicked outside the input fields
    @param value - input validation case
    @param field - field name
    */
    onBlurValidation(value, field) {
        if (value) {
            this.otherValBlur = false;
            this.positionValBlur = false;
            this.nameValBlur = false;
            this.commentsOnActValBlur = false;
            this.commentsOnGenValBlur = false;
            this.dataValBlur = false;
            this.remarkableValBlur = false;
            this.onlyNumber = this.validationMsg.onlyNumVal;
            this.onlyAlphabet = "Please enter only alphabets";
            this.avoidSpecialChar = "Please enter alphabets & numbers";
            switch (field) {
                case "Others":
                    if  (!value.match(/^[a-zA-Z0-9&/.#,\s-]*$/)) {
                        this.comments.otherSource = '';
                        this.otherValBlur = true;
                        this.setTimeOut();
                    }
                    break;

                case "CommentsOnActivity":
                    if  (!value.match(/^[a-zA-Z0-9&/.#,\s-]*$/)) {
                        this.comments.commentsOnActivity = '';
                        this.commentsOnActValBlur = true;
                        this.setTimeOut();
                    }
                    break;

                case "CommentsOnGeneral":
                    if (!(value.match(/^[a-zA-Z&/.#,\s-]*$/))) {
                        this.comments.commentOnGeneralWorkFirm = '';
                        this.commentsOnGenValBlur = true;
                        this.setTimeOut();
                    }
                    break;

                case "Position":
                    if  (!value.match(/^[a-zA-Z0-9&/.#,\s-]*$/)) {
                        this.comments.positionOfStatutoryDues = '';
                        this.positionValBlur = true;
                        this.setTimeOut();
                    }
                    break;

                case "DataCollection":
                    if  (!value.match(/^[a-zA-Z0-9&/.#,\s-]*$/)) {
                        this.comments.commentsOnDataCollection = '';
                        this.dataValBlur = true;
                        this.setTimeOut();
                    }
                    break;

                case "remarkablePoint":
                    if  (!value.match(/^[a-zA-Z0-9&/.#,\s-]*$/)) {
                        this.comments.remarkablePointFromBorrower = '';
                        this.remarkableValBlur = true;
                        this.setTimeOut();
                    }
                    break;

                case "Name":
                    if (!(value.match(/^[a-zA-Z.\s]*$/))) {
                        this.comments.nameOfAccompanyingOfficial = '';
                        this.nameValBlur = true;
                        this.setTimeOut();
                    }
                    break;
            }
        }
    }

    /**
    This function is called when user clicked on the submit button. If there is any missing field, page will redirect to that corresponding page
    */
    pageRedirect() {
        if (this.submissionStatusMessage == "You have submitted your Inspection from Web. To add images please open the Inspection in Mobile") {
            this.router.navigate(['sme']);
        } else {
            let firstMessage = this.submissionStatusMessage.toLowerCase().split("details");
            let navigateUrl = "";

            if (firstMessage[0].indexOf("unit") > -1) {
                navigateUrl = "/sme/presanctionDetail/borrowerDetails/unitDetails";
            } else if (firstMessage[0].indexOf("key") > -1) {
                navigateUrl = "/sme/presanctionDetail/borrowerDetails/keyPersonDetails";
            } else if (firstMessage[0].indexOf("contact") > -1) {
                navigateUrl = "/sme/presanctionDetail/borrowerDetails/contactPersonDetails";
            } else if (firstMessage[0].indexOf("guarantor") > -1) {
                navigateUrl = "/sme/presanctionDetail/guarantorDetails";
            } else if (firstMessage[0].indexOf("establishment") > -1) {
                navigateUrl = "/sme/presanctionDetail/establishmentDetails";
            } else if (firstMessage[0].indexOf("collateral") > -1) {
                navigateUrl = "/sme/presanctionDetail/collateralDetails";
            } else if (firstMessage[0].indexOf("particular") > -1) {
                navigateUrl = "/sme/presanctionDetail/loanRequested";
            } else {
                navigateUrl = "/sme/presanctionDetail/comments";
            }

            this.router.navigate([navigateUrl]);
        }
    }
}