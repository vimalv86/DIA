import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { DIAConstants } from '../../../../Shared/constants';
import { Constants } from '../../../../Shared/Constants/constants.service';
import { UtilsService } from '../../../../Shared/UtilsService/utils.service';

import { LiabilityDetails } from '../../../../Service/SME/Presanction/PresentLiabilities/liabilityDetails';
import { AddLiabilityDetailsService } from '../../../../Service/SME/Presanction/PresentLiabilities/AddLiabilityDetails/addLiabilityDetails.service';
import { RemoveLiabilityDetailsService } from '../../../../Service/SME/Presanction/PresentLiabilities/RemoveLiabilityDetails/removeLiabilityDetails.service';
import { SmePresanctionGetLiabilityDetailsService } from '../../../../Service/SME/Presanction/PresentLiabilities/GetLiabilityDetails/getLiabilityDetails.service';

import { ConfirmationService } from 'primeng/primeng';
import { ValidationMessageService } from '../../../../Shared/ValidationMsgs/validationMsg.service';

@Component({
  selector: 'presentLiabilities',
  templateUrl: './presentLiabilities.component.html',
  styleUrls: ['./presentLiabilities.component.scss', '../../../module.component.scss'],
  providers: [
    LiabilityDetails,
    AddLiabilityDetailsService,
    SmePresanctionGetLiabilityDetailsService,
    ConfirmationService,
    RemoveLiabilityDetailsService,
    UtilsService,
    Constants,
    ValidationMessageService
  ]
})

export class PresentLiabilitiesComponent implements OnInit {
  private apiRequest: any;
  private responseStatus: Object = [];
  private liabilityList: any;
  private executivePFIndex: any;
  private borrowerRefId: string;
  private status: boolean;
  private message: string;
  private statusMsg: string;
  private noData: boolean;
  private facilityType: any = [];
  private sanctionDate: any;
  private pfId: string;
  private isDisabled: boolean;
  private isOtherLoansDisabled: boolean;
  private isValidationComplete: boolean;
  private isLoanEditable: boolean;
  private loanDetailsWithOutInspection: any;
  private otherVal: boolean = false;
  private accountVal: boolean = false;
  private limitedVal: boolean = false;
  private marketVal: boolean = false;
  private advanceVal: boolean = false;
  private drawingVal: boolean = false;
  private outstandingVal: boolean = false;
  private otherValBlur: boolean = false;
  private accountValBlur: boolean = false;
  private limitedValBlur: boolean = false;
  private marketValBlur: boolean = false;
  private advanceValBlur: boolean = false;
  private drawingValBlur: boolean = false;
  private outstandingValBlur: boolean = false;
  private onlyNumber: string;
  private onlyAlphabet: string;
  private avoidSpecialChar: string;
  private currentDate: any;
  private isAccountNoValid: boolean = true;
  private isAccountNoLengthValid: boolean = true;
  private isLimitValid: boolean = true;
  private isMarketValueValid: boolean = true;
  private isAdvancedValid: boolean = true;
  private isDrawingValid: boolean = true;
  private isOutstandingValid: boolean = true;
  private validationMsg: any;
  private dateOfSanctionStatus: boolean = false;
  private typeOfFacilityStatus: boolean = false;
  private otherLoanStatus: boolean = false;
  private accountNumberStatus: boolean = false;
  private limitedSantionedStatus: boolean = false;
  private marketValueStatus: boolean = false;
  private advanceValueStatus: boolean = false;
  private drawingPowerStatus: boolean = false;
  private outSatndingAmountStatus: boolean = false;
  private sanctionDateStatus: boolean = false;
  private responseData: any = {};
  private clearLiabilityResponseData: any = {};

  constructor(private _addLiabilityDetailsService: AddLiabilityDetailsService, private service: SmePresanctionGetLiabilityDetailsService, private route: ActivatedRoute, private confirmationService: ConfirmationService, private _removeLiabilityDetailsService: RemoveLiabilityDetailsService, private utilsService: UtilsService, private constants: Constants, private validationMessageService: ValidationMessageService) {
    this.facilityType = DIAConstants.facilityType;
    this.sanctionDate = '';
    this.currentDate = new Date();
  }

  @Input() liabilityDetails: LiabilityDetails;
  /**
  This function is used for adding the liability details
  */
  addLiabilityDetail() {
    if (this.borrowerRefId) {
      this.isValidationComplete = true;
      if (this.liabilityDetails.facilityType && this.liabilityDetails.accountNumber && this.liabilityDetails.limitSanction && this.liabilityDetails.marketValue && this.sanctionDate && this.liabilityDetails.liabilityExist && this.liabilityDetails.drawingPower && this.liabilityDetails.advancedValue) {
        if (this.liabilityDetails.facilityType == "Others") {
          if (!this.liabilityDetails.others) {
            this.isValidationComplete = false;
            this.typeOfFacilityStatus = true;
          } else {
            this.typeOfFacilityStatus = false;
          }
        }
        if (this.liabilityDetails.accountNumber.length < 11) {
          this.isAccountNoLengthValid = false;
        }
        else {
          this.isAccountNoLengthValid = true;
        }
        if (this.liabilityDetails.accountNumber.charAt(0) == '0') {
          this.isAccountNoValid = false;
        }
        else {
          this.isAccountNoValid = true;
        }
        if (this.liabilityDetails.limitSanction.charAt(0) == '0') {
          this.isLimitValid = false;
        }
        else {
          this.isLimitValid = true;
        }
        if (this.liabilityDetails.marketValue.charAt(0) == '0') {
          this.isMarketValueValid = false;
        }
        else {
          this.isMarketValueValid = true;
        }
        if (this.liabilityDetails.advancedValue.charAt(0) == '0') {
          this.isAdvancedValid = false;
        }
        else {
          this.isAdvancedValid = true;
        }
        if (this.liabilityDetails.drawingPower.charAt(0) == '0') {
          this.isDrawingValid = false;
        }
        else {
          this.isDrawingValid = true;
        }
        if (this.liabilityDetails.outstandingAmount.charAt(0) == '0') {
          this.isOutstandingValid = false;
        }
        else {
          this.isOutstandingValid = true;
        }
        if (this.isValidationComplete && this.isAccountNoValid && this.isLimitValid && this.isMarketValueValid && this.isAdvancedValid && this.isDrawingValid && this.isOutstandingValid && this.isAccountNoLengthValid) {
          let actualTime = this.sanctionDate;
          let timeStamp = new Date(actualTime).getTime().toString();
          this.liabilityDetails["dateOfSanctionTS"] = timeStamp;
          this.liabilityDetails["borrowerRefId"] = this.borrowerRefId;

          var objectToPost: { borrowerLiabilityVO: object; appId: string; executivePFIndex: string; } = { borrowerLiabilityVO: this.liabilityDetails, appId: "WEB-DIA", executivePFIndex: this.pfId };

          this._addLiabilityDetailsService.postComment(objectToPost).subscribe(
            data => {
              this.responseData = data;
              console.log(this.responseStatus = this.responseData);
              if (this.responseData.responseMessage == "Successful") {
                this.message = this.constants.getMessage('successMsg');
                this.isOtherLoansDisabled = false;
                this.statusMsg = "success";
                this.getLiability();
              } else {
                this.message = this.responseData.responseMessage;
                this.statusMsg = "error";
              }
            },
            err => {
              console.log(err);
              this.message = this.constants.getMessage('errorMsg');
              this.statusMsg = "error";
            },
            () => console.log('Request Completed')
          );
          this.status = true;
          this.setTimeOut();
        } else {
          if (!this.isValidationComplete) {
            this.message = this.constants.getMessage('requiredFieldVal');
            this.statusMsg = "error";
          }
          else if (!this.isAccountNoLengthValid) {
            this.message = this.constants.getMessage('AccountNoVal');
            this.statusMsg = "error";
          }
          else if (!this.isAccountNoValid) {
            this.message = this.constants.getMessage('AccountNoVal');
            this.statusMsg = "error";
          }
          else if (!this.isLimitValid) {
            this.message = this.constants.getMessage('LimitVal');
            this.statusMsg = "error";
          }
          else if (!this.isMarketValueValid) {
            this.message = this.constants.getMessage('MarketVal');
            this.statusMsg = "error";
          }
          else if (!this.isAdvancedValid) {
            this.message = this.constants.getMessage('AdvancedVal');
            this.statusMsg = "error";
          }
          else if (!this.isDrawingValid) {
            this.message = this.constants.getMessage('DrawingVal');
            this.statusMsg = "error";
          }
          else if (!this.isOutstandingValid) {
            this.message = this.constants.getMessage('OutstandingVal');
            this.statusMsg = "error";
          }
          this.setTimeOut();
        }
      } else {
        this.message = this.constants.getMessage('requiredFieldVal');
        this.statusMsg = "error";
        this.setTimeOut();
        if (!this.liabilityDetails.facilityType) {
          this.typeOfFacilityStatus = true;
        } else {
          this.typeOfFacilityStatus = false;
        }

        if (this.liabilityDetails.facilityType == "Others" && !this.liabilityDetails.others) {
          this.otherLoanStatus = true;
        } else {
          this.otherLoanStatus = false;
        }

        if (!this.liabilityDetails.accountNumber) {
          this.accountNumberStatus = true;
        } else {
          this.accountNumberStatus = false;
        }

        if (!this.liabilityDetails.limitSanction) {
          this.limitedSantionedStatus = true;
        } else {
          this.limitedSantionedStatus = false;
        }

        if (!this.liabilityDetails.marketValue) {
          this.marketValueStatus = true;
        } else {
          this.marketValueStatus = false;
        }

        if (!this.liabilityDetails.drawingPower) {
          this.drawingPowerStatus = true;
        } else {
          this.drawingPowerStatus = false;
        }

        if (!this.liabilityDetails.advancedValue) {
          this.advanceValueStatus = true;
        } else {
          this.advanceValueStatus = false;
        }

        if (!this.sanctionDate) {
          this.sanctionDateStatus = true;
        } else {
          this.sanctionDateStatus = false;
        }
      }
    } else {
      this.message = this.constants.getMessage('unitDetailVal');
      this.statusMsg = "error";
      this.setTimeOut();
    }
  }

  /**
  This function is used for setting the timeout
  */
  setTimeOut() {
    setTimeout(() => {
      this.message = "";
      this.onlyNumber = "";
      this.onlyAlphabet = "";
      this.avoidSpecialChar = "";
      this.dateOfSanctionStatus = false;
      this.typeOfFacilityStatus = false;
      this.otherLoanStatus = false;
      this.accountNumberStatus = false;
      this.limitedSantionedStatus = false;
      this.marketValueStatus = false;
      this.advanceValueStatus = false;
      this.drawingPowerStatus = false;
      this.outSatndingAmountStatus = false;
      this.sanctionDateStatus = false;
    }, 3000);
  }

  /**
  This function is called when component loads
  */
  ngOnInit() {
    this.liabilityDetails = new LiabilityDetails();
    this.liabilityDetails.liabilityExist = "0";
    this.isDisabled = true;
    if (localStorage.getItem("isLoanEditable") != null && localStorage.getItem("isLoanEditable") != "null") {
      if (localStorage.getItem("isLoanEditable") == "true") {
        this.isLoanEditable = true;
      } else {
        this.isLoanEditable = false;
      }
    }
    if (localStorage.getItem("userDetails") != "null" && localStorage.getItem("userDetails") != null && localStorage.getItem("borrowerRefID") != "null" && localStorage.getItem("borrowerRefID") != null) {
      this.executivePFIndex = JSON.parse(localStorage.getItem("userDetails"));
      this.pfId = this.executivePFIndex.user.pfId.toString();
      this.borrowerRefId = JSON.parse(localStorage.getItem('borrowerRefID'));
      this.getLiability();
    } else {
      this.getDataFromLocalStorage();
    }
    this.getValidationMessage();
  }

  /**
  This function is used for getting the validation messages
  */
  getValidationMessage() {
    this.validationMessageService.getValidationMessage().subscribe(response => {
      if (response) {
        this.validationMsg = response;
      } else {
        console.log("Something worng");
      }
    })
  }

  /**
  This function is used for getting the liability details
  */
  getLiability() {
    this.apiRequest = { "appId": "WEB-DIA", "executivePFIndex": this.pfId, "key": this.borrowerRefId };
    this.service.getLiabilityDetails(this.apiRequest).subscribe(response => {
      if (response.borrowerLiabilityList) {
        //this.registredAddressUnit = JSON.parse(localStorage.getItem("registredAddressUnit"));
        this.liabilityList = response.borrowerLiabilityList;
        if (this.liabilityList.length == 0) {
          this.liabilityDetails.liabilityExist = "0";
        } else {
          this.liabilityDetails.liabilityExist = "1";
          this.isDisabled = false;
        }
        this.liabilityDetails.facilityType = "";
        this.liabilityDetails.others = "";
        this.liabilityDetails.accountNumber = "";
        this.liabilityDetails.limitSanction = "";
        this.liabilityDetails.dateOfSanctionTS = "";
        this.liabilityDetails.drawingPower = "";
        this.liabilityDetails.advancedValue = "";
        this.liabilityDetails.marketValue = "";
        this.liabilityDetails.outstandingAmount = "";
      } else {
        this.getDataFromLocalStorage();
      }
    })
  }

  /**
  This function is used for getting the liability details from the local storage
  */
  getDataFromLocalStorage() {
    this.loanDetailsWithOutInspection = JSON.parse(localStorage.getItem("loanDetailsWithOutInspection"));
    if (this.loanDetailsWithOutInspection) {
      if (this.loanDetailsWithOutInspection.libilityList && this.loanDetailsWithOutInspection.libilityList.length > 0) {
        this.liabilityList = this.loanDetailsWithOutInspection.libilityList;
        if (this.liabilityList.length == 0) {
          this.liabilityDetails.liabilityExist = "0";
        } else {
          this.liabilityDetails.liabilityExist = "1";
          this.isDisabled = false;
        }
        this.liabilityDetails.facilityType = "";
        this.liabilityDetails.others = "";
        this.liabilityDetails.accountNumber = "";
        this.liabilityDetails.limitSanction = "";
        this.liabilityDetails.dateOfSanctionTS = "";
        this.liabilityDetails.drawingPower = "";
        this.liabilityDetails.advancedValue = "";
        this.liabilityDetails.marketValue = "";
        this.liabilityDetails.outstandingAmount = "";
      } else {
        this.noData = true;
      }
    } else {
      this.noData = true;
    }
  }

  /**
  This function is used when user select liability option as Yes/No
  */
  liabilitySelect(data) {
    if (data == "1") {
      this.isDisabled = false;
    } else {
      this.isDisabled = true;
      if (this.liabilityList && this.liabilityList.length > 0) {
        this.confirmationService.confirm({
          message: this.constants.getMessage('delPopUpMsg'),
          accept: () => {
            this.clearLiabilities();
          }
        });
      }
    }
  }

  /**
  This function is used to clear the liability list
  */
  clearLiabilities() {
    let liabilityRefIdList = [];
    for (let k = 0; k < this.liabilityList.length; k++) {
      liabilityRefIdList.push(this.liabilityList[k].liabilityRefId);
    }
    var objectToPost: { borrowerLiabilityRefIdList: object; appId: string; executivePFIndex: string; } = { borrowerLiabilityRefIdList: liabilityRefIdList, appId: "WEB-DIA", executivePFIndex: this.pfId };

    this._removeLiabilityDetailsService.postComment(objectToPost).subscribe(
      data => {
        this.clearLiabilityResponseData = data;
        console.log(this.responseStatus = data);
        if (this.clearLiabilityResponseData.responseMessage == "Successful") {
          this.message = this.constants.getMessage('liabilityDelSuccMsg');
          this.statusMsg = "success";
          this.getLiability();
        } else {
          this.message = this.clearLiabilityResponseData.responseMessage;
          this.statusMsg = "error";
        }
      },
      err => {
        console.log(err);
        this.message = this.constants.getMessage('liabilityDelFailMsg');
        this.statusMsg = "error";
      },
      () => console.log('Request Completed')
    );
    this.status = true;
    this.setTimeOut();
  }

  /**
  This function is used when user select loan purpose from the dropdown
  */
  loanPurposeSelection(data) {
    if (data == "Others") {
      this.isOtherLoansDisabled = true;
    } else {
      this.isOtherLoansDisabled = false;
      this.liabilityDetails.others = null;
    }
  }

  /**
    This function is called when user clicked on the input fields
    @param data - input validation case
    @param field - field name
    @return data - input validation case
    */
  keypressCheck(data, field) {
    this.otherVal = false;
    this.accountVal = false;
    this.limitedVal = false;
    this.marketVal = false;
    this.advanceVal = false;
    this.drawingVal = false;
    this.outstandingVal = false;
    switch (field) {
      case "Other":
        if (this.utilsService.validString) {
          this.otherVal = true;
        } else {
          this.otherVal = false;
        }
        break;

      case "Account":
        if (this.utilsService.validString) {
          this.accountVal = true;
        } else {
          this.accountVal = false;
        }
        break;

      case "Limited":
        if (this.utilsService.validString) {
          this.limitedVal = true;
        } else {
          this.limitedVal = false;
        }
        break;

      case "Market":
        if (this.utilsService.validString) {
          this.marketVal = true;
        } else {
          this.marketVal = false;
        }
        break;

      case "Advance":
        if (this.utilsService.validString) {
          this.advanceVal = true;
        } else {
          this.advanceVal = false;
        }
        break;

      case "Drawing":
        if (this.utilsService.validString) {
          this.drawingVal = true;
        } else {
          this.drawingVal = false;
        }
        break;

      case "Outstanding":
        if (this.utilsService.validString) {
          this.outstandingVal = true;
        } else {
          this.outstandingVal = false;
        }
        break;
    }
    return data;
  }

  /**
    This function is called when user clicked outside the input fields
    @param value - input validation case
    @param field - field name
    */
  onBlurValidation(value, field) {
    if (value) {
      this.otherValBlur = false;
      this.accountValBlur = false;
      this.limitedValBlur = false;
      this.marketValBlur = false;
      this.advanceValBlur = false;
      this.drawingValBlur = false;
      this.outstandingValBlur = false;
      this.onlyNumber = this.validationMsg.onlyNumVal;
      this.onlyAlphabet = "Please enter only alphabets";
      this.avoidSpecialChar = "Please enter alphabets & numbers";
      switch (field) {
        case "Other":
          if (!(value.match(/^[a-zA-Z&/.#,\s-]*$/))) {
            this.liabilityDetails.others = '';
            this.otherValBlur = true;
            this.setTimeOut();
          }
          break;

        case "Limited":
          if (!(value.match(/^\d+$/))) {
            this.liabilityDetails.limitSanction = '';
            this.limitedValBlur = true;
            this.setTimeOut();
          }
          break;

        case "Account":
          if (!(value.match(/^\d+$/))) {
            this.liabilityDetails.accountNumber = '';
            this.accountValBlur = true;
            this.setTimeOut();
          }
          break;

        case "Market":
          if (!(value.match(/^\d+$/))) {
            this.liabilityDetails.marketValue = '';
            this.marketValBlur = true;
            this.setTimeOut();
          }
          break;

        case "Advance":
          if (!(value.match(/^\d+$/))) {
            this.liabilityDetails.advancedValue = '';
            this.advanceValBlur = true;
            this.setTimeOut();
          }
          break;

        case "Drawing":
          if (!(value.match(/^\d+$/))) {
            this.liabilityDetails.drawingPower = '';
            this.drawingValBlur = true;
            this.setTimeOut();
          }
          break;

        case "Outstanding":
          if (!(value.match(/^\d+$/))) {
            this.liabilityDetails.outstandingAmount = '';
            this.outstandingValBlur = true;
            this.setTimeOut();
          }
          break;
      }
    }
  }
}