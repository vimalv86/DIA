import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

import { Constants } from '../../../../Shared/Constants/constants.service';
import { UtilsService } from '../../../../Shared/UtilsService/utils.service';
import { ValidationMessageService } from '../../../../Shared/ValidationMsgs/validationMsg.service';

@Component({
    selector: 'presanction-new',
    templateUrl: './presanctionNew.component.html',
    styleUrls: ['./presanctionNew.component.scss', '../../../module.component.scss'],
    providers: [
        Constants,
        UtilsService,
        ValidationMessageService
    ]
})

export class PresanctionNewComponent implements OnInit {
    constructor(private router: Router, private constants: Constants, private utilsService: UtilsService, private validationMessageService: ValidationMessageService) {
        this.currentDate = new Date();
    }

    private searchLoanWithout: boolean = false;
    private losNumber: any;
    private branchCode: string;
    private fromDate: any;
    private toDate: any;
    private fromTimeStamp: any;
    private toTimeStamp: any;
    private searchWithLos: string = "LOS Number";
    private searchWithBranch: string;
    private image: string;
    private statusMsg: string;
    private timer: any;
    private LOSVal: boolean = false;
    private BranchVal: boolean = false;
    private currentDate: any;
    private LOSValBlur: boolean = false;
    private BranchValBlur: boolean = false;
    private onlyNumber: string;
    private BranchLength: string;
    private LOSLength: string;
    private validationMsg: any;
    private maximumToDate: any;
    private maximumFromDate: any;
    private dateValMsg: any;

    /**
    This function is used when user clicked on the radio buttons in presanction page
    @params: status - id of the radio button
    @return Nothing
    */
    searchCategory(status) { //radio button selection
        this.router.navigate(['sme/detail/presanctionNew']);
        this.searchWithLos = "";
        this.searchWithBranch = "";
        clearTimeout(this.timer);
        if (status === 1) {
            this.searchLoanWithout = false;
            this.branchCode = "";
            this.fromDate = "";
            this.toDate = "";
            this.BranchLength = "";
            this.onlyNumber = "";
            this.LOSLength = "";
            this.searchWithLos = "LOS Number";
        } else if (status === 2) {
            this.searchLoanWithout = false;
            this.losNumber = null;
            this.BranchLength = "";
            this.onlyNumber = "";
            this.LOSLength = "";
            this.fromDate = "";
            this.toDate = "";
            this.searchWithBranch = "Branch Code";
        } else if (status === 3) {
            this.searchLoanWithout = true;
            this.losNumber = null;
            this.branchCode = "";
            this.fromDate = "";
            this.BranchLength = "";
            this.onlyNumber = "";
            this.LOSLength = "";
            this.toDate = "";
            this.searchWithLos = "";
            this.searchWithBranch = "";
        }
    }

    /**
    This function is used for searching the loan list
    @return Nothing
    */
    searchLoanList = function () {
        clearTimeout(this.timer);
        localStorage.setItem("rejectedCount", "0");
        if (localStorage.getItem("userDetails") != null && localStorage.getItem("userDetails") != "null") {
            this.executivePFIndex = JSON.parse(localStorage.getItem("userDetails"));
            if (this.executivePFIndex.user) {
                this.pfId = this.executivePFIndex.user.pfId.toString();
                localStorage.setItem("isLoanEditable", "true");
                if (this.branchCode) {
                    if (this.branchCode.length < 5) {
                        this.BranchLength = this.constants.getMessage('BranchLength');
                        this.setTimeOut();
                    } else if (this.branchCode == "00000") {
                        this.BranchLength = this.constants.getMessage('BranchLength');
                        this.setTimeOut();
                    } else {
                        this.BranchLength = "";
                        localStorage.setItem("isCollateralEditable", "false");
                        let convertfromDateFormat = new Date(this.fromDate);
                        this.fromTimeStamp = convertfromDateFormat.getTime();
                        let convertToDateFormat = new Date(this.toDate);
                        this.toTimeStamp = convertToDateFormat.getTime();
                        let noOfDays = this.calculateNoOfDays(new Date(this.fromTimeStamp), new Date(this.toTimeStamp))
                        if (this.fromTimeStamp > this.toTimeStamp) {
                            this.statusMsg = this.constants.getMessage('DateVal');
                            this.setTimeOut();
                        } else if (noOfDays > 90) {
                            this.statusMsg = this.constants.getMessage('DateValLimit');
                            this.setTimeOut();
                        } else {
                            this.router.navigate(['sme/detail/presanctionNew/presanctionList', { branchCode: this.branchCode, fromTimeStamp: this.fromTimeStamp, toTimeStamp: this.toTimeStamp }]);
                        }
                    }
                } else if (this.losNumber) {
                    if (this.losNumber.length < 15) {
                        this.LOSLength = this.constants.getMessage('LOSLength');
                        this.setTimeOut();
                    } else {
                        this.LOSLength = "";
                        if (this.losNumber.charAt(0) == '0') {
                            this.LOSLength = this.constants.getMessage('LOSLength');
                            this.setTimeOut();
                        } else {
                            localStorage.setItem("loanNo", JSON.stringify(this.losNumber));
                            localStorage.setItem("isCollateralEditable", "false");
                            this.router.navigate(['sme/detail/presanctionNew/presanctionList', { losNumber: this.losNumber }]);
                        }
                    }
                } else {
                    localStorage.setItem("UnitName", null);
                    localStorage.setItem("loanDetailsWithOutInspection", null);
                    localStorage.setItem("isCollateralEditable", "true");
                    localStorage.setItem("borrowerRefID", null);
                    localStorage.setItem("loanNo", null);
                    localStorage.setItem("inspectionID", null);
                    localStorage.setItem("registredAddressUnit", null);
                    localStorage.setItem("salutationAddress", null);
                    this.router.navigate(['sme/presanctionDetail/borrowerDetails/unitDetails']);
                }
            } else {
                this.statusMsg = this.constants.getMessage('PFIDVal');
                this.setTimeOut();
            }
        } else {
            this.statusMsg = this.constants.getMessage('PFIDVal');
        }
    };

    /**
    This function is used for setting the timeout
    @return Nothing
    */
    setTimeOut() {
        this.timer = setTimeout(() => {
            this.statusMsg = "";
            this.onlyNumber = "";
            this.BranchLength = "";
            this.LOSLength = "";
            this.dateValMsg = '';
        }, 3000);
    }

    /**
    This function is called when component loads
    @return Nothing
    */
    ngOnInit() {
        this.getValidationMessage();
        this.maximumToDate = new Date();
        this.maximumFromDate = new Date();
    }

    /**
    This function is used when user select start date
    @params: fromDate - start date
    @return Nothing
    */
    selectFromDate(fromDate) {
        let dateFromAndTo = fromDate;
        let dateConversion = new Date(dateFromAndTo);
        this.maximumToDate = new Date(dateConversion.setDate(dateConversion.getDate() + 90));
        if (this.maximumToDate > new Date()) {
            this.maximumToDate = new Date();
        }
        if (this.toDate == "") {
            this.toDate = this.maximumToDate;
        }
        else if (this.toDate > this.maximumToDate) {
            this.toDate = this.maximumToDate;
        }
        if (this.fromDate > this.toDate) {
            this.toDate = this.maximumToDate;
            this.setTimeOut();
        }
    }

    /**
    This function is used when user select end date
    @params: fromDate - end date
    @return Nothing
    */
    selectToDate(toDate) {
        if (this.fromDate > this.toDate) {
            this.dateValMsg = 'From Date should be less than To Date';
            this.setTimeOut();
        }
    }

    /**
    This function is used for getting the validation message
    @params: fromDate - end date
    @return Nothing
    */
    getValidationMessage() {
        this.validationMessageService.getValidationMessage().subscribe(response => {
            if (response) {
                this.validationMsg = response;
            } else {
                console.log("Something worng");
            }
        })
    }

    /**
    This function is called when user clicked on the input fields
    @param data - input validation case
    @param field - field name
    @return data - input validation case
    */
    keypressCheck(data, field) {
        this.LOSVal = false;
        switch (field) {
            case "LOS":
                if (this.utilsService.validString) {
                    this.LOSVal = true;
                    this.BranchVal = false;
                } else {
                    this.LOSVal = false;
                }
                break;

            case "Branch":
                if (this.utilsService.validString) {
                    this.BranchVal = true;
                } else {
                    this.BranchVal = false;
                }
                break;
        }
        return data;
    }

    /**
    This function is used for calculating the days between start date and end date
    @param fromDate - start date
    @param toDate - end date
    @return diffDays - No of days
    */
    calculateNoOfDays(fromDate, toDate) {
        var oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
        var firstDate = new Date(fromDate);
        var secondDate = new Date(toDate);

        var diffDays = Math.round(Math.abs((firstDate.getTime() - secondDate.getTime()) / (oneDay)));
        return diffDays;
    }

    /**
    This function is called when user clicked outside the input fields
    @param value - input validation case
    @param field - field name
    */
    onBlurValidation(value, field) {
        if (value) {
            this.LOSValBlur = false;
            this.BranchValBlur = false;
            this.onlyNumber = this.validationMsg.onlyNumVal;
            switch (field) {
                case "LOS":
                    if (!(value.match(/^\d+$/))) {
                        this.losNumber = '';
                        this.LOSValBlur = true;
                        this.setTimeOut();
                    } else if (value.length < 15 || value.charAt(0) == '0') {
                        this.losNumber = '';
                        this.onlyNumber = this.constants.getMessage('LOSLength');
                        this.LOSValBlur = true;
                        this.setTimeOut();
                    }
                    break;

                case "Branch":
                    if (!(value.match(/^\d+$/))) {
                        this.branchCode = '';
                        this.BranchValBlur = true;
                        this.setTimeOut();
                    } else if (value.length < 5 || value == '00000') {
                        this.onlyNumber = this.constants.getMessage('BranchLength');
                        this.branchCode = '';
                        this.setTimeOut();
                    }
                    break;
            }
        }
    }
}